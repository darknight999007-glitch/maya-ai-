package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.DefaultToolsData
import com.example.data.model.MayaPersona
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun readStringFromContext() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("MAYA AI", appName)
    }

    @Test
    fun verifyMayaToolsAndCategoriesCounts() {
        val tools = DefaultToolsData.getInitialTools()
        val categories = DefaultToolsData.categories

        // Verify exactly 234 tools and 24 categories as per Maya 6.0 brochure specification
        assertEquals(234, tools.size)
        assertEquals(24, categories.size)

        // Verify category sum matches 234
        val totalReported = categories.sumOf { it.count }
        assertEquals(234, totalReported)

        // Verify Core essentials has 68 tools
        val coreTools = tools.filter { it.category == "Core essentials" }
        assertEquals(68, coreTools.size)

        // Verify PC control has 25 tools
        val pcTools = tools.filter { it.category == "PC control" }
        assertEquals(25, pcTools.size)

        // Verify Accessibility has 25 tools
        val accessTools = tools.filter { it.category == "Accessibility" }
        assertEquals(25, accessTools.size)
    }

    @Test
    fun verifyPersonasAvailable() {
        val personas = MayaPersona.values()
        assertEquals(3, personas.size)
        assertTrue(personas.any { it.name == "MAYA" })
        assertTrue(personas.any { it.name == "FRIDAY" })
        assertTrue(personas.any { it.name == "VENOM" })
    }
}
