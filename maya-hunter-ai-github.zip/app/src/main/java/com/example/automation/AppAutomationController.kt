package com.example.automation

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import com.example.service.MayaAccessibilityService

object AppAutomationController {

    private val commonPackageMap = mapOf(
        "youtube" to "com.google.android.youtube",
        "ইউটিউব" to "com.google.android.youtube",
        "facebook" to "com.facebook.katana",
        "ফেসবুক" to "com.facebook.katana",
        "whatsapp" to "com.whatsapp",
        "হোয়াটসঅ্যাপ" to "com.whatsapp",
        "chrome" to "com.android.chrome",
        "ক্রোম" to "com.android.chrome",
        "browser" to "com.android.chrome",
        "ব্রাউজার" to "com.android.chrome",
        "maps" to "com.google.android.apps.maps",
        "ম্যাপ" to "com.google.android.apps.maps",
        "gmail" to "com.google.android.gm",
        "জিমেইল" to "com.google.android.gm",
        "play store" to "com.android.vending",
        "প্লে স্টোর" to "com.android.vending",
        "settings" to "com.android.settings",
        "সেটিংস" to "com.android.settings"
    )

    fun launchAppByName(context: Context, appName: String): Pair<Boolean, String> {
        val cleanName = appName.lowercase().trim()

        // 1. Check known mapping
        for ((key, pkg) in commonPackageMap) {
            if (cleanName.contains(key)) {
                val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    return Pair(true, "$key অ্যাপ সফলভাবে ওপেন করা হয়েছে।")
                }
            }
        }

        // 2. Special system apps (Camera, Settings, Phone dialer)
        if (cleanName.contains("camera") || cleanName.contains("ক্যামেরা")) {
            val cameraIntent = Intent("android.media.action.IMAGE_CAPTURE").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (cameraIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(cameraIntent)
                return Pair(true, "ক্যামেরা ওপেন করা হয়েছে।")
            }
        }

        if (cleanName.contains("setting") || cleanName.contains("সেটিংস")) {
            val settingsIntent = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(settingsIntent)
            return Pair(true, "ফোন সেটিংস ওপেন করা হয়েছে।")
        }

        // 3. Scan installed apps for matching label
        val pm = context.packageManager
        val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        for (app in installedApps) {
            val label = pm.getApplicationLabel(app).toString().lowercase()
            if (label.contains(cleanName) || cleanName.contains(label)) {
                val launchIntent = pm.getLaunchIntentForPackage(app.packageName)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    return Pair(true, "$label অ্যাপ ওপেন করা হয়েছে।")
                }
            }
        }

        return Pair(false, "\"$appName\" অ্যাপটি ফোনে খুঁজে পাওয়া যায়নি।")
    }

    fun searchYouTubeOrWeb(context: Context, query: String): Pair<Boolean, String> {
        val cleanQuery = query.replace("ইউটিউবে", "")
            .replace("ইউটিউব", "")
            .replace("play", "", ignoreCase = true)
            .replace("search", "", ignoreCase = true)
            .replace("খোঁজো", "")
            .replace("বাজাও", "")
            .trim()

        try {
            val ytIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(cleanQuery))).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(ytIntent)
            return Pair(true, "ইউটিউবে \"$cleanQuery\" সার্চ এবং প্লে করা হচ্ছে।")
        } catch (e: Exception) {
            val webIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra(SearchManager.QUERY, cleanQuery)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(webIntent)
            return Pair(true, "গুগল এ \"$cleanQuery\" সার্চ করা হয়েছে।")
        }
    }

    fun executeAccessibilityAction(actionKeyword: String): Pair<Boolean, String> {
        val accessibility = MayaAccessibilityService.instance
        if (accessibility == null) {
            return Pair(false, "অটোমেশন কার্যকর করতে Settings থেকে Maya Accessibility Service চালু করুন।")
        }

        val lower = actionKeyword.lowercase()
        return when {
            lower.contains("হোম") || lower.contains("ডাইরেক্ট ব্যাক") || lower.contains("home") -> {
                val ok = accessibility.performGoHome()
                Pair(ok, if (ok) "হোম স্ক্রিনে ফিরে আসা হয়েছে।" else "হোম অ্যাকশন ব্যর্থ হয়েছে।")
            }
            lower.contains("ব্যাক") || lower.contains("পিছনে") || lower.contains("back") -> {
                val ok = accessibility.performGoBack()
                Pair(ok, if (ok) "এক ধাপ পিছনে যাওয়া হয়েছে।" else "ব্যাক অ্যাকশন ব্যর্থ হয়েছে।")
            }
            lower.contains("রিসেন্ট") || lower.contains("recent") -> {
                val ok = accessibility.performRecentApps()
                Pair(ok, "রিসেন্ট অ্যাপস দেখানো হচ্ছে।")
            }
            lower.contains("ফলো") || lower.contains("follow") || lower.contains("লাইক") || lower.contains("like") -> {
                val ok = accessibility.clickFollowButton()
                Pair(ok, if (ok) "স্ক্রিনে থাকা ফলো/লাইক বাটনে ক্লিক করা হয়েছে।" else "স্ক্রিনে কোনো ফলো বাটন দেখতে পাইনি।")
            }
            lower.contains("স্ক্রোল") || lower.contains("scroll") || lower.contains("নিচে নামাও") -> {
                val ok = accessibility.scrollDown()
                Pair(ok, "স্ক্রোল করা হয়েছে।")
            }
            lower.contains("উপরে তোলো") || lower.contains("scroll up") -> {
                val ok = accessibility.scrollUp()
                Pair(ok, "উপরে স্ক্রোল করা হয়েছে।")
            }
            else -> Pair(false, "অজানা সিস্টেম অ্যাকশন।")
        }
    }
}
