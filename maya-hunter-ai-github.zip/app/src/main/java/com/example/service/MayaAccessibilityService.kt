package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MayaAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "MayaAccessibility"
        var instance: MayaAccessibilityService? = null
            private set

        val isServiceEnabled: Boolean
            get() = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "MayaAccessibilityService connected successfully")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Can monitor window state changes if needed
    }

    override fun onInterrupt() {
        Log.w(TAG, "MayaAccessibilityService interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    // 1. Navigation Gestures
    fun performGoBack(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_BACK)
    }

    fun performGoHome(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_HOME)
    }

    fun performRecentApps(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_RECENTS)
    }

    fun performOpenNotifications(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    }

    // 2. Automated Clicking & Node Interactions
    fun clickByText(targetText: String, ignoreCase: Boolean = true): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(targetText)
        if (!nodes.isNullOrEmpty()) {
            for (node in nodes) {
                if (ignoreCase && !node.text?.toString().equals(targetText, ignoreCase = true)) {
                    // Check partial match
                    if (node.text?.toString()?.contains(targetText, ignoreCase = true) != true) continue
                }
                var target: AccessibilityNodeInfo? = node
                while (target != null && !target.isClickable) {
                    target = target.parent
                }
                if (target != null && target.isClickable) {
                    val clicked = target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    if (clicked) return true
                }
            }
        }
        return false
    }

    fun clickFollowButton(): Boolean {
        val keywords = listOf("Follow", "অনুসরণ করুন", "ফলো", "Followed", "Like", "পছন্দ")
        for (kw in keywords) {
            if (clickByText(kw)) return true
        }
        return false
    }

    // 3. Search and Type automation
    fun typeTextIntoSearch(textToType: String): Boolean {
        val root = rootInActiveWindow ?: return false
        // Find editable field
        val editableNodes = mutableListOf<AccessibilityNodeInfo>()
        findEditableNodes(root, editableNodes)

        if (editableNodes.isNotEmpty()) {
            val target = editableNodes.first()
            val arguments = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, textToType)
            }
            target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val setResult = target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
            return setResult
        }
        return false
    }

    private fun findEditableNodes(node: AccessibilityNodeInfo?, result: MutableList<AccessibilityNodeInfo>) {
        if (node == null) return
        if (node.isEditable || node.className?.contains("EditText", ignoreCase = true) == true) {
            result.add(node)
        }
        for (i in 0 until node.childCount) {
            findEditableNodes(node.getChild(i), result)
        }
    }

    // 4. Custom Screen Tap Gesture
    fun tapAtScreenCoordinate(x: Float, y: Float, durationMs: Long = 100) {
        val path = Path().apply {
            moveTo(x, y)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        dispatchGesture(gesture, null, null)
    }

    // 5. Scroll automation
    fun scrollDown(): Boolean {
        val root = rootInActiveWindow ?: return false
        return root.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    fun scrollUp(): Boolean {
        val root = rootInActiveWindow ?: return false
        return root.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }
}
