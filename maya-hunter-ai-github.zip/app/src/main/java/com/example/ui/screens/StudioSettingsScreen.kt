package com.example.ui.screens

import android.provider.Settings
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PictureInPicture
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.service.MayaAccessibilityService
import com.example.service.MayaFloatingService
import com.example.ui.MayaViewModel
import com.example.ui.components.PermissionsHubModal
import com.example.ui.components.PremiumSubscriptionModal
import com.example.ui.theme.MayaCyan
import com.example.ui.theme.MayaDarkBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun StudioSettingsScreen(
    viewModel: MayaViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val memories by viewModel.allMemories.collectAsStateWithLifecycle()
    val subscriptionState by viewModel.subscriptionState.collectAsStateWithLifecycle()

    var isAddMemoryOpen by remember { mutableStateOf(false) }
    var memoryKeyInput by remember { mutableStateOf("") }
    var memoryContentInput by remember { mutableStateOf("") }

    var isPremiumModalOpen by remember { mutableStateOf(false) }
    var isPermissionsModalOpen by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "settings_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val goldBorder = remember {
        Brush.horizontalGradient(
            listOf(Color(0xFFFFD54F), Color(0xFFFFB300), Color(0xFFFF8F00), Color(0xFFFFD54F))
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MayaDarkBg)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 32.dp)
    ) {
        // Page Title Header
        item {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(Color(0xFFFFD54F))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "MAYA SYSTEM CONTROL & SETTINGS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = Color(0xFFFFD54F)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "স্মার্ট সেটিংস ও কন্ট্রোল প্যানেল",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimary
                )
                Text(
                    text = "ভয়েস, অটোমেশন, গুগল ড্রাইভ ক্লাউড ব্যাকআপ ও প্রিমিয়ার মেম্বারশিপ",
                    fontSize = 13.sp,
                    color = TextSecondary
                )
            }
        }

        // 1. PREMIER PRO SUBSCRIPTION & TRIAL CARD (ঘর ঘর সাইজ)
        item {
            val isPro = subscriptionState?.status == "PRO_ACTIVE"
            val isPending = subscriptionState?.status == "PENDING"

            UniqueSettingsCard(
                title = "প্রিমিয়ার প্রো মেম্বারশিপ",
                subtitle = if (isPro) "প্রো সক্রিয় রয়েছে · আনলিমিটেড ভয়েস" else if (isPending) "পেমেন্ট পেন্ডিং ভেরিফিকেশন" else "৩ দিনের ফ্রি ট্রায়াল সক্রিয় রয়েছে",
                icon = Icons.Default.WorkspacePremium,
                accentColor = Color(0xFFFFD54F),
                goldBorder = goldBorder
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "বিকাশ ও নগদ পেমেন্ট গেটওয়ে",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "TrxID দিয়ে সাবস্ক্রিপশন চালু রাখুন। মেয়াদ শেষ হলে স্বয়ংক্রিয় নোটিফিকেশন পাবেন।",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }

                    Button(
                        onClick = { isPremiumModalOpen = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD54F)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (isPro) "প্ল্যান" else "আপগ্রেড",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF04141E)
                        )
                    }
                }
            }
        }

        // 2. UNLIMITED CONTINUOUS VOICE & FEMALE PERSONA CARD
        item {
            UniqueSettingsCard(
                title = "ভয়েস ইঞ্জিন ও হ্যান্ডস-ফ্রি লিসেনিং",
                subtitle = "সারাক্ষণ শুনতে থাকা ও প্রাকৃতিক ফিমেল ভয়েস",
                icon = Icons.Default.Mic,
                accentColor = Color(0xFF00E5FF),
                goldBorder = goldBorder
            ) {
                // Continuous Listening Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "সারাক্ষণ ভয়েস মোড (Continuous Listening)",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "কথা শেষ হলেও নিজে থেকে ভয়েস বন্ধ হবে না, সারাক্ষণ শুনবে।",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                    Switch(
                        checked = viewModel.voiceEngine.isContinuousListening,
                        onCheckedChange = { viewModel.toggleContinuousListening() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF00E5FF),
                            checkedTrackColor = Color(0x5500E5FF)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Floating Movable Ball Overlay Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "ডিসপ্লেতে ভাসমান বল (Floating Overlay)",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "অ্যাপ বন্ধ করলেও স্ক্রিনে ছোট মুভযোগ্য অরভ ভাসবে।",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                    Switch(
                        checked = MayaFloatingService.isRunning,
                        onCheckedChange = { enable ->
                            if (Settings.canDrawOverlays(context)) {
                                if (enable) viewModel.startFloatingService()
                                else viewModel.stopFloatingService()
                            } else {
                                isPermissionsModalOpen = true
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFFFFD54F),
                            checkedTrackColor = Color(0x55FFD54F)
                        )
                    )
                }
            }
        }

        // 3. APP AUTOMATION & ACCESSIBILITY CONTROLS
        item {
            val isAccEnabled = MayaAccessibilityService.isServiceEnabled

            UniqueSettingsCard(
                title = "ডিভাইস ও অ্যাপ অটোমেশন",
                subtitle = "ইউটিউব সার্চ, ফেসবুক ফলো, অটো ক্লিক ও স্ক্রিন রিড",
                icon = Icons.Default.AccessibilityNew,
                accentColor = Color(0xFF00E676),
                goldBorder = goldBorder
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Maya Accessibility Service",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = if (isAccEnabled) "সার্ভিসটি সচল রয়েছে · হ্যান্ডস-ফ্রি অটোমেশন কার্যকর" else "সার্ভিসটি বন্ধ রয়েছে · অন করতে ট্যাপ করুন",
                            fontSize = 11.sp,
                            color = if (isAccEnabled) Color(0xFF00E676) else Color(0xFFFF9800)
                        )
                    }

                    Button(
                        onClick = { isPermissionsModalOpen = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isAccEnabled) Color(0x3300E676) else MayaCyan
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (isAccEnabled) "কনফিগার" else "অন করুন",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isAccEnabled) Color(0xFF00E676) else Color(0xFF04141E)
                        )
                    }
                }
            }
        }

        // 4. GOOGLE DRIVE CLOUD SYNC & LONG-TERM MEMORIES
        item {
            val isDriveLinked = subscriptionState?.isGoogleDriveConnected == true

            UniqueSettingsCard(
                title = "গুগল ড্রাইভ ও লং-টার্ম মেমোরি",
                subtitle = "কথোপকথন ও তথ্যের ১ মাসের ক্লাউড ব্যাকআপ",
                icon = Icons.Default.CloudDone,
                accentColor = Color(0xFF2979FF),
                goldBorder = goldBorder
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Google Drive ক্লাউড সিঙ্ক",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = if (isDriveLinked) "ড্রাইভ সংযুক্ত রয়েছে · কথা বলা ডাটা ড্রাইভে সুরক্ষিত" else "১ ক্লিকে নিজের গুগল ড্রাইভ কানেক্ট করে রাখুন",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }

                    Button(
                        onClick = { viewModel.toggleGoogleDrive(!isDriveLinked) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isDriveLinked) Color(0x3300E676) else MayaCyan
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (isDriveLinked) "Connected" else "Connect",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDriveLinked) Color(0xFF00E676) else Color(0xFF04141E)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "সংরক্ষিত মেমোরি সমূহ (${memories.size})",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Button(
                        onClick = { isAddMemoryOpen = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0x3380DEEA)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = MayaCyan)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "নতুন মেমোরি", fontSize = 11.sp, color = MayaCyan)
                    }
                }

                if (memories.isEmpty()) {
                    Text(
                        text = "এখনও কোনো স্থায়ী তথ্য সেভ করা হয়নি। কথা বলার সময় 'মনে রেখো' বললে মায়া নিজে থেকে মনে রাখবে।",
                        fontSize = 11.sp,
                        color = TextMuted,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                        memories.take(4).forEach { mem ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0x280B1C29))
                                    .border(1.dp, Color(0x3380DEEA), RoundedCornerShape(12.dp))
                                    .padding(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = mem.key, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFD54F))
                                        Text(text = mem.content, fontSize = 11.sp, color = TextPrimary)
                                    }
                                    IconButton(onClick = { viewModel.deleteMemory(mem.id) }, modifier = Modifier.size(24.dp)) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFFF5252), modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 5. AI ENGINE & GEMINI LIVE MODEL SELECTION
        item {
            UniqueSettingsCard(
                title = "এআই ইঞ্জিন ও জেমিনি লাইভ বাইন্ড",
                subtitle = "Google Gemini Live, Claude Code ও লোকাল রিজনার",
                icon = Icons.Default.SmartToy,
                accentColor = Color(0xFFFF4081),
                goldBorder = goldBorder
            ) {
                Text(
                    text = "সক্রিয় মডেল: ${uiState.selectedModelEndpoint}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF80DEEA)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "সার্ভার-সাইড জেমিনি লাইভ এপিআই সক্রিয় রয়েছে। ব্যবহারকারীর ভয়েস ও টেক্সট সরাসরি উচ্চ-ক্ষমতাসম্পন্ন এআই মডেল দ্বারা পরিচালিত হচ্ছে।",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    lineHeight = 15.sp
                )
            }
        }
    }

    // Add Memory Dialog
    if (isAddMemoryOpen) {
        AlertDialog(
            onDismissRequest = { isAddMemoryOpen = false },
            title = { Text("নতুন দীর্ঘমেয়াদী মেমোরি যুক্ত করুন", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = memoryKeyInput,
                        onValueChange = { memoryKeyInput = it },
                        label = { Text("কীওয়ার্ড (যেমন: 'আমার প্রিয় কাজ')") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFFD54F),
                            unfocusedBorderColor = Color(0x3380DEEA),
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = memoryContentInput,
                        onValueChange = { memoryContentInput = it },
                        label = { Text("তথ্য / স্মৃতি বিবরণ") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFFD54F),
                            unfocusedBorderColor = Color(0x3380DEEA),
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (memoryKeyInput.isNotBlank() && memoryContentInput.isNotBlank()) {
                            viewModel.addMemory(memoryKeyInput.trim(), memoryContentInput.trim(), "Personal")
                            memoryKeyInput = ""
                            memoryContentInput = ""
                            isAddMemoryOpen = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD54F))
                ) {
                    Text("সেভ করুন", color = Color(0xFF04141E), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Button(
                    onClick = { isAddMemoryOpen = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
                ) {
                    Text("বাতিল", color = TextMuted)
                }
            },
            containerColor = Color(0xF50D1C28),
            shape = RoundedCornerShape(20.dp)
        )
    }

    if (isPremiumModalOpen) {
        PremiumSubscriptionModal(
            subscriptionState = subscriptionState,
            onDismiss = { isPremiumModalOpen = false },
            onSubmitPayment = { method, trxId, plan ->
                viewModel.submitPayment(method, trxId, plan)
            },
            onAdminApprove = {
                viewModel.approveProSubscription()
            },
            onToggleGoogleDrive = { connected ->
                viewModel.toggleGoogleDrive(connected)
            }
        )
    }

    if (isPermissionsModalOpen) {
        PermissionsHubModal(
            hasMicPermission = true,
            onDismiss = { isPermissionsModalOpen = false },
            onRequestMic = {}
        )
    }
}

// UNIQUE SETTINGS CARD ("ঘর ঘর সাইজ" ও সোনালী আলোর বর্ডারসহ)
@Composable
private fun UniqueSettingsCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    goldBorder: Brush,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0x35112536))
            .border(1.5.dp, goldBorder, RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(accentColor.copy(alpha = 0.22f))
                        .border(1.dp, accentColor, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            content()
        }
    }
}
