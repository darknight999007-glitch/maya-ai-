package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MayaPersona
import com.example.ui.theme.MayaBorder
import com.example.ui.theme.MayaCrimson
import com.example.ui.theme.MayaCyan
import com.example.ui.theme.MayaDarkBg
import com.example.ui.theme.MayaEmerald
import com.example.ui.theme.MayaSurface
import com.example.ui.theme.MayaSurfaceVariant
import com.example.ui.theme.PersonaFridayColor
import com.example.ui.theme.PersonaMayaColor
import com.example.ui.theme.PersonaVenomColor
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

// 1. MUSIC PLAYER MODAL (for "Music" button)
@Composable
fun MusicPlayerModal(
    onDismiss: () -> Unit,
    onCommand: (String) -> Unit
) {
    var isPlaying by remember { mutableStateOf(true) }
    var currentTrack by remember { mutableStateOf("Lo-Fi Cyber Beats · Focus Radio") }
    var volume by remember { mutableFloatStateOf(0.75f) }

    val playlist = listOf(
        "Lo-Fi Cyber Beats · Focus Radio",
        "Deep Synthwave · Coding Runner",
        "Ambient Rain & Thunder in Tokyo",
        "Chillstep Meditation · 432Hz"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MayaSurface,
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MayaCyan.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.MusicNote, contentDescription = null, tint = MayaCyan, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("Maya Music Studio", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("YouTube & Spotify Link (8 Tools)", fontSize = 11.sp, color = TextSecondary)
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Active Track Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MayaSurfaceVariant)
                        .border(1.dp, MayaBorder, RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text(
                            text = if (isPlaying) "NOW PLAYING (24 kHz)" else "PAUSED",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isPlaying) MayaEmerald else TextMuted
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = currentTrack,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { if (isPlaying) 0.45f else 0.2f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = MayaCyan,
                            trackColor = MayaDarkBg
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Playback Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        val prevIdx = (playlist.indexOf(currentTrack) - 1 + playlist.size) % playlist.size
                        currentTrack = playlist[prevIdx]
                        onCommand("Skip to previous music track")
                    }) {
                        Icon(imageVector = Icons.Default.FastRewind, contentDescription = "Prev", tint = TextPrimary)
                    }

                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(MayaCyan)
                            .clickable {
                                isPlaying = !isPlaying
                                onCommand(if (isPlaying) "Resume playing music" else "Pause current music")
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = MayaDarkBg,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    IconButton(onClick = {
                        val nextIdx = (playlist.indexOf(currentTrack) + 1) % playlist.size
                        currentTrack = playlist[nextIdx]
                        onCommand("Skip to next track on YouTube")
                    }) {
                        Icon(imageVector = Icons.Default.FastForward, contentDescription = "Next", tint = TextPrimary)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Volume Slider
                Text(text = "Volume: ${(volume * 100).toInt()}%", fontSize = 11.sp, color = TextSecondary)
                Slider(
                    value = volume,
                    onValueChange = { volume = it },
                    colors = SliderDefaults.colors(thumbColor = MayaCyan, activeTrackColor = MayaCyan)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = MayaCyan),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Done", color = MayaDarkBg, fontWeight = FontWeight.Bold)
            }
        }
    )
}

// 2. STUDY & WHITEBOARD MODAL (for "Study" button)
@Composable
fun StudyModal(
    onDismiss: () -> Unit,
    onAskTopic: (String) -> Unit
) {
    val topics = listOf(
        "Explain how a Transformer neural network works",
        "Compare Kotlin Coroutines vs Java Threads",
        "Quantum computing superposition in simple terms",
        "How does OAuth2 Authorization Code Flow work?"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MayaSurface,
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFFD54F).copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.School, contentDescription = null, tint = Color(0xFFFFD54F), modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("Study & Whiteboard", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("Interactive Learning (6 Tools)", fontSize = 11.sp, color = TextSecondary)
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Pick a topic or question — Maya will explain it clearly with speech and visual concepts:",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 16.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                topics.forEach { topic ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MayaSurfaceVariant)
                            .border(1.dp, MayaBorder, RoundedCornerShape(10.dp))
                            .clickable {
                                onAskTopic(topic)
                                onDismiss()
                            }
                            .padding(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Lightbulb, contentDescription = null, tint = Color(0xFFFFD54F), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = topic, fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD54F)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Close", color = MayaDarkBg, fontWeight = FontWeight.Bold)
            }
        }
    )
}

// 3. JOURNAL & MEMORY MODAL (for "Journal" button)
@Composable
fun JournalModal(
    onDismiss: () -> Unit,
    onSaveEntry: (String) -> Unit
) {
    var entryText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MayaSurface,
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE040FB).copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = null, tint = Color(0xFFE040FB), modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("Voice Journal & Memory", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("Local plain-file memory storage", fontSize = 11.sp, color = TextSecondary)
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Record a thought, routine, or personal preference. Maya stores it locally on disk and recalls it whenever relevant:",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 16.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = entryText,
                    onValueChange = { entryText = it },
                    placeholder = { Text("Write or dictate memory (বাংলা বা ইংরেজি)...", color = TextMuted) },
                    minLines = 3,
                    maxLines = 6,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFE040FB),
                        unfocusedBorderColor = MayaBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (entryText.isNotBlank()) {
                        onSaveEntry(entryText.trim())
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE040FB)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Save Memory", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss, shape = RoundedCornerShape(10.dp)) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

// 4. WEATHER DETAIL SHEET (for Weather Card)
@Composable
fun WeatherDetailSheet(
    onDismiss: () -> Unit,
    onVoiceWeather: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MayaSurface,
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.WbSunny, contentDescription = null, tint = Color(0xFFFFB300), modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Weather Forecast · 26°C", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Condition: Clear & Sunny skies with gentle breeze.", fontSize = 12.sp, color = TextSecondary)
                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    WeatherStatBox("Humidity", "48%", "Optimal", Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    WeatherStatBox("Wind", "12 km/h", "East-NE", Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    WeatherStatBox("UV Index", "3 (Low)", "Safe", Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(14.dp))
                Text("3-DAY OUTLOOK", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextMuted, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Today (Fri)", fontSize = 12.sp, color = TextPrimary)
                    Text("26° / 19° · Sunny ☀️", fontSize = 12.sp, color = MayaCyan)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Tomorrow (Sat)", fontSize = 12.sp, color = TextPrimary)
                    Text("27° / 20° · Clear 🌤️", fontSize = 12.sp, color = MayaCyan)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Sunday", fontSize = 12.sp, color = TextPrimary)
                    Text("25° / 18° · Mild ⛅", fontSize = 12.sp, color = MayaCyan)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onVoiceWeather()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB300)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Speak Weather Out Loud", color = MayaDarkBg, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun WeatherStatBox(title: String, value: String, sub: String, modifier: Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(MayaSurfaceVariant)
            .padding(8.dp)
    ) {
        Column {
            Text(title, fontSize = 10.sp, color = TextMuted)
            Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(sub, fontSize = 9.sp, color = MayaCyan)
        }
    }
}

// 5. DATE & AGENDA MODAL (for Date Card)
@Composable
fun DateAgendaModal(
    onDismiss: () -> Unit,
    onDailyBriefing: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MayaSurface,
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Schedule, contentDescription = null, tint = MayaCyan, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Agenda · Fri, Oct 2", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Today's Synchronized Events & Routines:", fontSize = 12.sp, color = TextSecondary)
                Spacer(modifier = Modifier.height(10.dp))

                AgendaItem("09:00 AM", "Morning Setup Macro (VS Code, Chrome, Spotify)", true)
                AgendaItem("02:00 PM", "Competitor Research Sub-Agent Follow-up", false)
                AgendaItem("06:00 PM", "YouTube Episode 12 Analytics Check", false)
                AgendaItem("11:10 PM", "Invoice Reminder & Auto PC Sleep", false)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onDailyBriefing()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = MayaCyan),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Run Daily Briefing", color = MayaDarkBg, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun AgendaItem(time: String, title: String, isDone: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(MayaSurfaceVariant)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(time, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = MayaCyan)
        Spacer(modifier = Modifier.width(8.dp))
        Text(title, fontSize = 11.sp, color = if (isDone) TextMuted else TextPrimary, modifier = Modifier.weight(1f))
        if (isDone) {
            Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = MayaEmerald, modifier = Modifier.size(14.dp))
        }
    }
}

// 6. MOOD & PERSONA SWITCHER MODAL (for Mood Card)
@Composable
fun MoodPersonaModal(
    currentPersona: MayaPersona,
    onSelectPersona: (MayaPersona) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MayaSurface,
        shape = RoundedCornerShape(20.dp),
        title = {
            Text("Mood & Personality", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Select Maya's voice pitch, speaking pace, and emotional tone:", fontSize = 12.sp, color = TextSecondary)
                Spacer(modifier = Modifier.height(10.dp))

                PersonaItem(
                    title = "Maya (Warm & Caring ❤️)",
                    desc = "Warm, Empathetic, speaks naturally like a close companion.",
                    accent = PersonaMayaColor,
                    isSelected = currentPersona == MayaPersona.MAYA,
                    onClick = {
                        onSelectPersona(MayaPersona.MAYA)
                        onDismiss()
                    }
                )

                PersonaItem(
                    title = "Friday (Professional ⚡)",
                    desc = "Crisp, concise, Tony Stark-style executive assistant.",
                    accent = PersonaFridayColor,
                    isSelected = currentPersona == MayaPersona.FRIDAY,
                    onClick = {
                        onSelectPersona(MayaPersona.FRIDAY)
                        onDismiss()
                    }
                )

                PersonaItem(
                    title = "Venom (Fierce 🖤)",
                    desc = "Deep, sarcastic symbiote tone, fierce and powerful.",
                    accent = PersonaVenomColor,
                    isSelected = currentPersona == MayaPersona.VENOM,
                    onClick = {
                        onSelectPersona(MayaPersona.VENOM)
                        onDismiss()
                    }
                )
            }
        },
        confirmButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = MayaCyan)) {
                Text("Done", color = MayaDarkBg, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun PersonaItem(title: String, desc: String, accent: Color, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) MayaSurfaceVariant else MayaDarkBg)
            .border(1.dp, if (isSelected) accent else MayaBorder, RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(10.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(accent))
                Spacer(modifier = Modifier.width(6.dp))
                Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(desc, fontSize = 10.sp, color = TextSecondary)
        }
    }
}

// 7. ENERGY CRYSTAL MODAL (for "1 ENERGY" badge)
@Composable
fun EnergyModal(
    onDismiss: () -> Unit,
    onBoostEnergy: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MayaSurface,
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Bolt, contentDescription = null, tint = Color(0xFFFFD54F), modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Quantum Energy & Compute", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Energy powers autonomous parallel sub-agents and high-speed voice synthesis:", fontSize = 12.sp, color = TextSecondary)
                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MayaSurfaceVariant)
                        .padding(14.dp)
                ) {
                    Column {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Current Energy", fontSize = 12.sp, color = TextSecondary)
                            Text("100% (1 Energy Unit)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFD54F))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { 1.0f },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = Color(0xFFFFD54F),
                            trackColor = MayaDarkBg
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("• Local Token Generation: 42 tokens/sec\n• GPU Throttling: None (Optimal)\n• Sub-agents in queue: 4 ready", fontSize = 11.sp, color = TextPrimary, lineHeight = 16.sp)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onBoostEnergy()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD54F)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Recharge Boost", color = MayaDarkBg, fontWeight = FontWeight.Bold)
            }
        }
    )
}

// 8. LICENSE ACTIVATION MODAL (for "Activate" button)
@Composable
fun LicenseActivationModal(
    onDismiss: () -> Unit,
    onActivate: (String) -> Unit
) {
    var promoCode by remember { mutableStateOf("") }
    var isActivated by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MayaSurface,
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Verified, contentDescription = null, tint = MayaCyan, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Activate Maya 6.0 License", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Unlock unlimited talk time, all 234 tools, autonomous parallel sub-agents, and persistent phone link with zero restrictions:",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 16.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = promoCode,
                    onValueChange = { promoCode = it },
                    placeholder = { Text("Enter license key or code (e.g. HUNTER60)", color = TextMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MayaCyan,
                        unfocusedBorderColor = MayaBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                if (isActivated) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("✓ Lifetime License Activated Successfully!", color = MayaEmerald, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    isActivated = true
                    onActivate(promoCode.ifBlank { "LIFETIME-HUNTER-60" })
                },
                colors = ButtonDefaults.buttonColors(containerColor = MayaCyan),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Activate", color = MayaDarkBg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss, shape = RoundedCornerShape(10.dp)) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}
