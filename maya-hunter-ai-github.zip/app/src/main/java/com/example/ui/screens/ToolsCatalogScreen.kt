package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.EntityTool
import com.example.ui.MayaViewModel
import com.example.ui.theme.MayaBorder
import com.example.ui.theme.MayaCrimson
import com.example.ui.theme.MayaCyan
import com.example.ui.theme.MayaDarkBg
import com.example.ui.theme.MayaEmerald
import com.example.ui.theme.MayaSurface
import com.example.ui.theme.MayaSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ToolsCatalogScreen(
    viewModel: MayaViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val filteredTools by viewModel.filteredTools.collectAsStateWithLifecycle()
    val allTools by viewModel.allTools.collectAsStateWithLifecycle()
    val categories = viewModel.categories

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MayaDarkBg)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "234 TOOLS · 24 CATEGORIES",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = MayaCrimson
                    )
                    Text(
                        text = "Everything a Voice Can Reach",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                // Active counter badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(MayaSurfaceVariant)
                        .border(1.dp, MayaBorder, RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "${filteredTools.size} Showing",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MayaCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Search Bar
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                placeholder = { Text("Search tools, categories, commands...", fontSize = 13.sp, color = TextMuted) },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = TextMuted)
                },
                trailingIcon = {
                    if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", tint = TextMuted)
                        }
                    }
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MayaCrimson,
                    unfocusedBorderColor = MayaBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = MayaCrimson
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tools_search_input")
            )
        }

        // Horizontal Category Filter Chips
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                val isSelected = uiState.selectedCategory == "All"
                CategoryChip(
                    label = "All (234)",
                    isSelected = isSelected,
                    onClick = { viewModel.selectCategory("All") }
                )
            }

            items(categories) { category ->
                val isSelected = uiState.selectedCategory == category.name
                CategoryChip(
                    label = "${category.name} (${category.count})",
                    isSelected = isSelected,
                    onClick = { viewModel.selectCategory(category.name) }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Tool Cards List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(
                items = filteredTools,
                key = { it.id }
            ) { tool ->
                ToolCardItem(
                    tool = tool,
                    onToggle = { viewModel.toggleTool(tool) },
                    onRunOnPc = { viewModel.executeToolOnPc(tool) },
                    onDetailClick = { viewModel.showToolDetail(tool) }
                )
            }
        }
    }

    // Tool Detail Dialog
    uiState.selectedToolForDetail?.let { tool ->
        AlertDialog(
            onDismissRequest = { viewModel.showToolDetail(null) },
            containerColor = MayaSurface,
            shape = RoundedCornerShape(16.dp),
            title = {
                Column {
                    Text(
                        text = tool.category.uppercase(),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MayaCyan,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = tool.name,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
            },
            text = {
                Column {
                    Text(
                        text = tool.description,
                        fontSize = 13.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "VOICE COMMAND SYNTAX:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MayaCrimson
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MayaSurfaceVariant)
                            .border(1.dp, MayaBorder, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "\"${tool.examplePrompt}\"",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            fontFamily = FontFamily.Monospace,
                            color = TextPrimary
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.executeToolOnPc(tool)
                        viewModel.showToolDetail(null)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MayaCrimson),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("dialog_run_button")
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Execute on PC")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { viewModel.showToolDetail(null) },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Close", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun CategoryChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (isSelected) MayaCrimson else MayaSurfaceVariant)
            .border(
                width = 1.dp,
                color = if (isSelected) MayaCrimson else MayaBorder,
                shape = RoundedCornerShape(20.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 7.dp)
            .testTag("category_chip_${label.take(8)}")
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) TextPrimary else TextSecondary
        )
    }
}

@Composable
private fun ToolCardItem(
    tool: EntityTool,
    onToggle: () -> Unit,
    onRunOnPc: () -> Unit,
    onDetailClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MayaSurface),
        shape = RoundedCornerShape(14.dp),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(if (tool.isEnabled) MayaBorder else MayaBorder.copy(alpha = 0.4f))
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onDetailClick() }
            .testTag("tool_card_${tool.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = tool.category.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MayaCyan
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = tool.name,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (tool.isEnabled) TextPrimary else TextMuted
                    )
                }

                Switch(
                    checked = tool.isEnabled,
                    onCheckedChange = { onToggle() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = TextPrimary,
                        checkedTrackColor = MayaCrimson,
                        uncheckedThumbColor = TextSecondary,
                        uncheckedTrackColor = MayaSurfaceVariant
                    ),
                    modifier = Modifier.testTag("tool_switch_${tool.id}")
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = tool.description,
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Voice Command Quote & Run Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MayaSurfaceVariant)
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "\"${tool.examplePrompt}\"",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextPrimary,
                        maxLines = 1
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = onRunOnPc,
                    colors = ButtonDefaults.buttonColors(containerColor = MayaCrimson),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("run_tool_${tool.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Run",
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Run on PC", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
