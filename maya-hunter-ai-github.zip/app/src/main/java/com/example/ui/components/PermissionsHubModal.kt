package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PictureInPicture
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.MayaAccessibilityService
import com.example.ui.theme.MayaCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PermissionsHubModal(
    hasMicPermission: Boolean,
    onDismiss: () -> Unit,
    onRequestMic: () -> Unit
) {
    val context = LocalContext.current
    val hasOverlayPermission = Settings.canDrawOverlays(context)
    val hasAccessibility = MayaAccessibilityService.isServiceEnabled

    val goldBorder = Brush.horizontalGradient(
        listOf(Color(0xFFFFD54F), Color(0xFFFFB300), Color(0xFFFF8F00))
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        containerColor = Color(0xF508131C),
        shape = RoundedCornerShape(24.dp),
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x33FFD54F))
                            .border(1.5.dp, Color(0xFFFFD54F), RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = Color(0xFFFFD54F),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "স্মার্ট সিস্টেম পারমিশন হাব",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFD54F)
                        )
                        Text(
                            text = "অটোমেশন ও ব্যাকগ্রাউন্ড কন্ট্রোল সক্রিয় করুন",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                // 1. Microphone Permission
                PermissionCard(
                    title = "১. মাইক্রোফোন পারমিশন (ভয়েস কমান্ড)",
                    description = "সারাক্ষণ হ্যান্ডস-ফ্রি ভয়েস ইনপুট ও কমান্ড শোনার জন্য প্রয়োজন।",
                    icon = Icons.Default.Mic,
                    isGranted = hasMicPermission,
                    buttonLabel = if (hasMicPermission) "অনুমোদিত" else "অনুমতি দিন",
                    onClick = onRequestMic
                )

                // 2. Floating Window Overlay
                PermissionCard(
                    title = "২. ডিসপ্লে ওভার আদার অ্যাপস (ফ্লোটিং বল)",
                    description = "অ্যাপ বন্ধ থাকলেও স্ক্রিনের উপরে ড্র্যাগযোগ্য ভাসমান বল রাখার জন্য।",
                    icon = Icons.Default.PictureInPicture,
                    isGranted = hasOverlayPermission,
                    buttonLabel = if (hasOverlayPermission) "অনুমোদিত" else "সেটিংস খুলুন",
                    onClick = {
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}")
                        ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                        context.startActivity(intent)
                    }
                )

                // 3. Accessibility Service
                PermissionCard(
                    title = "৩. অ্যাক্সেসিবিলিটি সার্ভিস (অটো কন্ট্রোল)",
                    description = "অন্য অ্যাপ ওপেন করা, অটোমেটিক সার্চ, টাইপ, ফেসবুক ফলো ও হোম/ব্যাক বাটন চাপার জন্য।",
                    icon = Icons.Default.AccessibilityNew,
                    isGranted = hasAccessibility,
                    buttonLabel = if (hasAccessibility) "অনুমোদিত" else "অন করুন",
                    onClick = {
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                    }
                )

                // 4. Notifications
                PermissionCard(
                    title = "৪. ব্যাকগ্রাউন্ড নোটিফিকেশন",
                    description = "অ্যান্ড্রয়েড যাতে ব্যাকগ্রাউন্ডে মায়া অ্যাসিস্ট্যান্ট কিল না করে।",
                    icon = Icons.Default.Notifications,
                    isGranted = true,
                    buttonLabel = "সক্রিয়",
                    onClick = {}
                )

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = MayaCyan),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(44.dp)
                ) {
                    Text(text = "সম্পন্ন (Done)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF04141E))
                }
            }
        }
    )
}

@Composable
private fun PermissionCard(
    title: String,
    description: String,
    icon: ImageVector,
    isGranted: Boolean,
    buttonLabel: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x2B132738))
            .border(1.5.dp, if (isGranted) Color(0x6600E676) else Color(0x55FFB300), RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (isGranted) Color(0xFF00E676) else Color(0xFFFFB300),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = title,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                if (isGranted) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF00E676),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = description,
                fontSize = 10.sp,
                color = TextSecondary,
                lineHeight = 14.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = onClick,
                enabled = !isGranted,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isGranted) Color(0x3300E676) else MayaCyan
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.align(Alignment.End).height(32.dp)
            ) {
                Text(
                    text = buttonLabel,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isGranted) Color(0xFF00E676) else Color(0xFF07141E)
                )
            }
        }
    }
}
