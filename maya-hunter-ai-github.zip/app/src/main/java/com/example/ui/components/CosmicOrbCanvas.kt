package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

private data class SphereParticle(
    val phi: Double,
    val theta: Double,
    val baseRadius: Float,
    val color: Color,
    val size: Float
)

private data class DustParticle(
    val xRatio: Float,
    val yRatio: Float,
    val radius: Float,
    val alpha: Float,
    val color: Color
)

@Composable
fun CosmicOrbCanvas(
    isSpeaking: Boolean,
    isListening: Boolean,
    waveformLevel: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "cosmic_orb")

    // Rotation angle for sphere
    val sphereAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isSpeaking) 6000 else 14000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sphere_rotation"
    )

    // Cyan orbit ring rotation
    val cyanOrbitAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isSpeaking) 4500 else 9000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "cyan_orbit"
    )

    // Gold orbit ring rotation
    val goldOrbitAngle by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isSpeaking) 5500 else 11000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "gold_orbit"
    )

    // Core plasma pulsation
    val plasmaPulse by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "plasma_swirl"
    )

    // Expanding sonic wave rings when speaking or listening
    val waveRipple by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isSpeaking) 1200 else 2400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_ripple"
    )

    // Pulse breathing scale
    val pulseBreathing by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isSpeaking) 500 else 2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathing"
    )

    // Precompute Fibonacci sphere particles once
    val particles = remember {
        val count = 180
        val colors = listOf(
            Color(0xFF00E5FF), // Neon Cyan
            Color(0xFF2979FF), // Electric Sapphire Blue
            Color(0xFFFFD54F), // Luminous Gold
            Color(0xFFFF4081), // Cyber Magenta
            Color(0xFFFFFFFF), // Pure White
            Color(0xFF80D8FF), // Ice Cyan
            Color(0xFF7C4DFF)  // Deep Purple
        )
        (0 until count).map { i ->
            val phi = acos(1.0 - 2.0 * (i + 0.5) / count)
            val theta = PI * (1.0 + sqrt(5.0)) * i
            val color = colors[i % colors.size]
            val size = 2.2f + (i % 4) * 0.8f
            SphereParticle(phi, theta, 1f, color, size)
        }
    }

    // Precompute subtle floating cosmic background stars
    val dustStars = remember {
        val random = java.util.Random(42)
        val colors = listOf(Color(0xFF00E5FF), Color(0xFFFFD54F), Color(0xFFFFFFFF), Color(0xFF80D8FF))
        (0 until 45).map {
            DustParticle(
                xRatio = random.nextFloat(),
                yRatio = random.nextFloat(),
                radius = 1.0f + random.nextFloat() * 1.8f,
                alpha = 0.25f + random.nextFloat() * 0.65f,
                color = colors[random.nextInt(colors.size)]
            )
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .clickable { onClick() }
            .testTag("cosmic_orb_canvas"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val maxAvailableDim = min(size.width, size.height)
            if (maxAvailableDim <= 0f) return@Canvas

            val center = Offset(size.width / 2f, size.height / 2f)
            val dynamicScale = if (isSpeaking) (pulseBreathing + waveformLevel * 0.12f) else pulseBreathing
            val baseRadius = (maxAvailableDim * 0.27f) * dynamicScale

            // 1. Draw subtle background cosmic dust stars
            dustStars.forEach { star ->
                val x = star.xRatio * size.width
                val y = star.yRatio * size.height
                drawCircle(
                    color = star.color.copy(alpha = star.alpha),
                    radius = star.radius,
                    center = Offset(x, y)
                )
            }

            // 2. Outward expanding acoustic energy ripple rings
            val rippleRadius1 = baseRadius * (1.05f + waveRipple * 0.7f)
            val rippleAlpha1 = ((1f - waveRipple) * (if (isSpeaking) 0.65f else 0.35f)).coerceIn(0f, 1f)
            drawCircle(
                color = (if (isSpeaking) Color(0xFFFF2A4D) else Color(0xFF00E5FF)).copy(alpha = rippleAlpha1),
                radius = rippleRadius1,
                center = center,
                style = Stroke(width = 1.8f)
            )

            val ripplePhase2 = (waveRipple + 0.5f) % 1f
            val rippleRadius2 = baseRadius * (1.05f + ripplePhase2 * 0.7f)
            val rippleAlpha2 = ((1f - ripplePhase2) * (if (isSpeaking) 0.5f else 0.25f)).coerceIn(0f, 1f)
            drawCircle(
                color = (if (isSpeaking) Color(0xFFFF5252) else Color(0xFF2979FF)).copy(alpha = rippleAlpha2),
                radius = rippleRadius2,
                center = center,
                style = Stroke(width = 1.5f)
            )

            // 3. Radial ambient core halo glow
            val glowColor1 = if (isSpeaking) Color(0xFFFF1744) else Color(0xFF00E5FF)
            val glowColor2 = if (isSpeaking) Color(0xFFFF5252) else Color(0xFF2979FF)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        glowColor1.copy(alpha = if (isSpeaking) 0.45f else 0.25f),
                        glowColor2.copy(alpha = if (isSpeaking) 0.22f else 0.12f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 1.6f
                ),
                center = center,
                radius = baseRadius * 1.6f
            )

            // 4. Draw Back Half of Orbital Rings (Z < 0)
            drawEllipticalOrbit(
                center = center,
                radiusX = baseRadius * 1.72f,
                radiusY = baseRadius * 0.62f,
                tiltAngleDeg = 36f,
                rotationAngleDeg = cyanOrbitAngle,
                strokeColor = Color(0xFF00E5FF),
                isDotted = false,
                isBackHalf = true,
                strokeWidth = 2.4f,
                satelliteColor = Color(0xFF80D8FF)
            )

            drawEllipticalOrbit(
                center = center,
                radiusX = baseRadius * 1.72f,
                radiusY = baseRadius * 0.62f,
                tiltAngleDeg = -34f,
                rotationAngleDeg = goldOrbitAngle,
                strokeColor = Color(0xFFFFD54F),
                isDotted = true,
                isBackHalf = true,
                strokeWidth = 2.2f,
                satelliteColor = Color(0xFFFFE082)
            )

            // 5. Internal glowing plasma core sphere (liquid animated core)
            val plasmaRad = Math.toRadians(plasmaPulse.toDouble())
            val coreOffsetX = (cos(plasmaRad) * (baseRadius * 0.12f)).toFloat()
            val coreOffsetY = (sin(plasmaRad) * (baseRadius * 0.12f)).toFloat()
            val plasmaCenter = Offset(center.x + coreOffsetX, center.y + coreOffsetY)

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = if (isSpeaking) 0.95f else 0.75f),
                        (if (isSpeaking) Color(0xFFFF5252) else Color(0xFF00E5FF)).copy(alpha = 0.85f),
                        (if (isSpeaking) Color(0xFFD50000) else Color(0xFF0D47A1)).copy(alpha = 0.70f),
                        Color(0xFF05111B)
                    ),
                    center = plasmaCenter,
                    radius = baseRadius * 0.88f
                ),
                center = center,
                radius = baseRadius * 0.88f
            )

            // Soundwave frequency bars radiating around the sphere rim
            val barCount = 36
            for (b in 0 until barCount) {
                val angle = (2 * PI * b / barCount).toFloat()
                val waveOffset = sin(angle * 4 + plasmaPulse * 0.05f)
                val barLen = (2.5f + (waveformLevel * 18f * (0.5f + 0.5f * waveOffset))).coerceIn(2f, 24f)
                val innerR = baseRadius * 0.90f
                val outerR = innerR + barLen
                val start = Offset(center.x + innerR * cos(angle), center.y + innerR * sin(angle))
                val end = Offset(center.x + outerR * cos(angle), center.y + outerR * sin(angle))
                drawLine(
                    color = (if (isSpeaking) Color(0xFFFF5252) else Color(0xFF00E5FF)).copy(alpha = if (isSpeaking) 0.85f else 0.45f),
                    start = start,
                    end = end,
                    strokeWidth = 2.2f
                )
            }

            // 6. Render rotating 3D particle sphere with Fibonacci distribution
            val radAngleY = Math.toRadians(sphereAngle.toDouble())
            val radAngleX = Math.toRadians((sin(Math.toRadians(sphereAngle * 0.5)) * 18.0))

            // Sort particles by projected Z so back particles draw first
            val projectedParticles = particles.map { p ->
                val x0 = baseRadius * sin(p.phi) * cos(p.theta)
                val y0 = baseRadius * sin(p.phi) * sin(p.theta)
                val z0 = baseRadius * cos(p.phi)

                // Rotate around Y axis
                val x1 = x0 * cos(radAngleY) + z0 * sin(radAngleY)
                val z1 = -x0 * sin(radAngleY) + z0 * cos(radAngleY)

                // Rotate around X axis
                val y2 = y0 * cos(radAngleX) - z1 * sin(radAngleX)
                val z2 = y0 * sin(radAngleX) + z1 * cos(radAngleX)

                val cameraDist = 800f
                val scale = cameraDist / (cameraDist - z2.toFloat())
                val screenX = center.x + (x1 * scale).toFloat()
                val screenY = center.y + (y2 * scale).toFloat()
                val depthNormalized = ((z2 / baseRadius) + 1.0) / 2.0 // 0.0 (far) to 1.0 (near)

                ProjectedPoint(
                    screenOffset = Offset(screenX, screenY),
                    depth = z2,
                    alpha = (0.22f + depthNormalized.toFloat() * 0.78f).coerceIn(0.1f, 1f),
                    size = (p.size * (0.6f + depthNormalized.toFloat() * 0.6f)),
                    color = if (isSpeaking && p.color == Color(0xFF00E5FF)) Color(0xFFFF5252) else p.color
                )
            }.sortedBy { it.depth }

            projectedParticles.forEach { pt ->
                drawCircle(
                    color = pt.color.copy(alpha = pt.alpha),
                    radius = pt.size,
                    center = pt.screenOffset
                )
            }

            // 7. Draw Front Half of Orbital Rings (Z >= 0) with glowing overlap & traveling satellites
            drawEllipticalOrbit(
                center = center,
                radiusX = baseRadius * 1.72f,
                radiusY = baseRadius * 0.62f,
                tiltAngleDeg = 36f,
                rotationAngleDeg = cyanOrbitAngle,
                strokeColor = Color(0xFF00E5FF),
                isDotted = false,
                isBackHalf = false,
                strokeWidth = 2.8f,
                satelliteColor = Color(0xFF80D8FF)
            )

            drawEllipticalOrbit(
                center = center,
                radiusX = baseRadius * 1.72f,
                radiusY = baseRadius * 0.62f,
                tiltAngleDeg = -34f,
                rotationAngleDeg = goldOrbitAngle,
                strokeColor = Color(0xFFFFD54F),
                isDotted = true,
                isBackHalf = false,
                strokeWidth = 2.5f,
                satelliteColor = Color(0xFFFFE082)
            )
        }
    }
}

private data class ProjectedPoint(
    val screenOffset: Offset,
    val depth: Double,
    val alpha: Float,
    val size: Float,
    val color: Color
)

private fun DrawScope.drawEllipticalOrbit(
    center: Offset,
    radiusX: Float,
    radiusY: Float,
    tiltAngleDeg: Float,
    rotationAngleDeg: Float,
    strokeColor: Color,
    isDotted: Boolean,
    isBackHalf: Boolean,
    strokeWidth: Float,
    satelliteColor: Color
) {
    val steps = 90
    val radTilt = Math.toRadians(tiltAngleDeg.toDouble())
    val cosTilt = cos(radTilt)
    val sinTilt = sin(radTilt)

    var prevPoint: Offset? = null

    // Satellite position angle along this orbit
    val satelliteT = Math.toRadians(rotationAngleDeg.toDouble() % 360.0)
    val satZ = sin(satelliteT)
    val isSatInThisHalf = (isBackHalf && satZ < 0) || (!isBackHalf && satZ >= 0)

    for (i in 0..steps) {
        val t = (2 * PI * i / steps)
        val z = sin(t) // Depth indicator for orbit: z < 0 back half, z >= 0 front half

        if (isBackHalf && z >= 0) {
            prevPoint = null
            continue
        }
        if (!isBackHalf && z < 0) {
            prevPoint = null
            continue
        }

        // Ellipse parametric
        val x0 = radiusX * cos(t)
        val y0 = radiusY * sin(t)

        // Rotate by tilt angle
        val rotX = x0 * cosTilt - y0 * sinTilt
        val rotY = x0 * sinTilt + y0 * cosTilt

        val curPoint = Offset((center.x + rotX).toFloat(), (center.y + rotY).toFloat())

        if (prevPoint != null) {
            if (isDotted) {
                if (i % 2 == 0) {
                    drawCircle(
                        color = strokeColor.copy(alpha = if (isBackHalf) 0.50f else 0.95f),
                        radius = strokeWidth * 0.75f,
                        center = curPoint
                    )
                }
            } else {
                drawLine(
                    color = strokeColor.copy(alpha = if (isBackHalf) 0.55f else 0.95f),
                    start = prevPoint,
                    end = curPoint,
                    strokeWidth = strokeWidth
                )
            }
        }
        prevPoint = curPoint
    }

    // Draw glowing satellite energy bead if in this half
    if (isSatInThisHalf) {
        val sx0 = radiusX * cos(satelliteT)
        val sy0 = radiusY * sin(satelliteT)
        val sRotX = sx0 * cosTilt - sy0 * sinTilt
        val sRotY = sx0 * sinTilt + sy0 * cosTilt
        val satPoint = Offset((center.x + sRotX).toFloat(), (center.y + sRotY).toFloat())

        // Halo
        drawCircle(
            color = satelliteColor.copy(alpha = if (isBackHalf) 0.35f else 0.75f),
            radius = strokeWidth * 2.8f,
            center = satPoint
        )
        // Core bead
        drawCircle(
            color = Color.White.copy(alpha = if (isBackHalf) 0.6f else 1.0f),
            radius = strokeWidth * 1.4f,
            center = satPoint
        )
    }
}
