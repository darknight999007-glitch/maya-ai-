package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.auth.UserProfile
import com.example.ui.MainTab
import com.example.ui.theme.MayaCyan
import com.example.ui.theme.MayaDarkBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MayaNavDrawerContent(
    currentTab: MainTab,
    userProfile: UserProfile,
    onNavigateTab: (MainTab) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenPermissions: () -> Unit,
    onOpenPremium: () -> Unit,
    onCloseDrawer: () -> Unit,
    modifier: Modifier = Modifier
) {
    val goldBorder = remember {
        Brush.horizontalGradient(
            listOf(Color(0xFFFFD54F), Color(0xFFFFB300), Color(0xFFFF8F00), Color(0xFFFFD54F))
        )
    }

    Column(
        modifier = modifier
            .fillMaxHeight()
            .width(320.dp)
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF040A12),
                        Color(0xFF061521),
                        Color(0xFF091F2F),
                        Color(0xFF050E17)
                    )
                )
            )
            .padding(vertical = 16.dp, horizontal = 14.dp)
    ) {
        // 1. TOP HEADER & USER PROFILE CARD (ক্লিক করলেই প্রোফাইল মডাল ওপেন হবে)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0x35142E40))
                .border(1.2.dp, goldBorder, RoundedCornerShape(18.dp))
                .clickable {
                    onOpenProfile()
                    onCloseDrawer()
                }
                .padding(12.dp)
                .testTag("drawer_profile_header")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.maya_avatar),
                        contentDescription = "User Avatar",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, Color(0xFFFFD54F), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = userProfile.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = userProfile.phone,
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFFFD54F))
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (userProfile.isPro) "PRO ACTIVE" else "৩ দিনের ফ্রি ট্রায়াল",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFFD54F)
                            )
                        }
                    }
                }

                IconButton(
                    onClick = {
                        onOpenProfile()
                        onCloseDrawer()
                    },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AccountCircle,
                        contentDescription = "Profile",
                        tint = Color(0xFFFFD54F),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        HorizontalDivider(color = Color(0x3380DEEA), thickness = 1.dp)
        Spacer(modifier = Modifier.height(8.dp))

        // 2. LARGE GLASSY BUTTON NAVIGATION ITEMS ("ঘর ঘর সাইজ ও প্রিমিয়াম স্টাইল")
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Group: HOME & CHAT
            item {
                DrawerSectionHeader(title = "CORE NAVIGATION")
            }
            item {
                GlassyDrawerButton(
                    title = "Home (লাইভ হাব ও স্পিচ)",
                    subtitle = "ভয়েস কমান্ড, লাইভ অরভ ও এজ লাইট",
                    icon = Icons.Default.Home,
                    isSelected = currentTab == MainTab.HUD,
                    goldBorder = goldBorder,
                    onClick = {
                        onNavigateTab(MainTab.HUD)
                        onCloseDrawer()
                    }
                )
            }
            item {
                GlassyDrawerButton(
                    title = "Live Chat (কথোপকথন হিস্ট্রি)",
                    subtitle = "৩০ দিনের অটোরিটেনশন ও মেমোরি",
                    icon = Icons.AutoMirrored.Filled.Chat,
                    isSelected = false,
                    goldBorder = goldBorder,
                    onClick = {
                        onNavigateTab(MainTab.HUD)
                        onCloseDrawer()
                    }
                )
            }

            // Group: PRODUCTIVITY
            item {
                Spacer(modifier = Modifier.height(6.dp))
                DrawerSectionHeader(title = "PRODUCTIVITY & TOOLS")
            }
            item {
                GlassyDrawerButton(
                    title = "Markets & Finance",
                    subtitle = "ক্রিপ্টো, স্টক ও রিয়েলটাইম মার্কেট",
                    icon = Icons.AutoMirrored.Filled.TrendingUp,
                    isSelected = false,
                    goldBorder = goldBorder,
                    onClick = {
                        onNavigateTab(MainTab.TOOLS)
                        onCloseDrawer()
                    }
                )
            }
            item {
                GlassyDrawerButton(
                    title = "Marketing & YouTube",
                    subtitle = "ইউটিউব গান প্লে ও অটো সার্চ",
                    icon = Icons.Default.Storefront,
                    isSelected = false,
                    goldBorder = goldBorder,
                    onClick = {
                        onNavigateTab(MainTab.TOOLS)
                        onCloseDrawer()
                    }
                )
            }
            item {
                GlassyDrawerButton(
                    title = "Documents & Drive",
                    subtitle = "গুগল ড্রাইভে ১-ক্লিক ক্লাউড সিঙ্ক",
                    icon = Icons.Default.Description,
                    isSelected = false,
                    goldBorder = goldBorder,
                    onClick = {
                        onNavigateTab(MainTab.TOOLS)
                        onCloseDrawer()
                    }
                )
            }
            item {
                GlassyDrawerButton(
                    title = "Website & Coding Engine",
                    subtitle = "Claude Code ও ফুলস্ট্যাক এজেন্ট",
                    icon = Icons.Default.Code,
                    isSelected = currentTab == MainTab.FLEET,
                    goldBorder = goldBorder,
                    onClick = {
                        onNavigateTab(MainTab.FLEET)
                        onCloseDrawer()
                    }
                )
            }
            item {
                GlassyDrawerButton(
                    title = "Study & Whiteboard",
                    subtitle = "স্টাডি ট্র্যাকার ও নোটস মেমো",
                    icon = Icons.Default.Edit,
                    isSelected = false,
                    goldBorder = goldBorder,
                    onClick = {
                        onNavigateTab(MainTab.TOOLS)
                        onCloseDrawer()
                    }
                )
            }

            // Group: SYSTEM & AUTOMATION
            item {
                Spacer(modifier = Modifier.height(6.dp))
                DrawerSectionHeader(title = "SYSTEM & AUTOMATION")
            }
            item {
                GlassyDrawerButton(
                    title = "Settings (স্মার্ট কন্ট্রোল)",
                    subtitle = "ভয়েস টিউনিং ও জেমিনি লাইভ বাইন্ড",
                    icon = Icons.Default.Settings,
                    isSelected = currentTab == MainTab.STUDIO,
                    goldBorder = goldBorder,
                    onClick = {
                        onOpenSettings()
                        onCloseDrawer()
                    }
                )
            }
            item {
                GlassyDrawerButton(
                    title = "অ্যাক্সেসিবিলিটি ও অ্যাপ কন্ট্রোল",
                    subtitle = "অটো-ক্লিক, হোম/ব্যাক ও ফলো কমান্ড",
                    icon = Icons.Default.AccessibilityNew,
                    isSelected = false,
                    goldBorder = goldBorder,
                    onClick = {
                        onOpenPermissions()
                        onCloseDrawer()
                    }
                )
            }
            item {
                GlassyDrawerButton(
                    title = "পারমিশন হাব ও সিকিউরিটি",
                    subtitle = "মাইক্রোফোন, ওভারলে ও ড্রাইভ অনুমতি",
                    icon = Icons.Default.Security,
                    isSelected = false,
                    goldBorder = goldBorder,
                    onClick = {
                        onOpenPermissions()
                        onCloseDrawer()
                    }
                )
            }
            item {
                GlassyDrawerButton(
                    title = "Maya Tools Catalog (234)",
                    subtitle = "উইন্ডোজ ডেস্কটপ ও মোবাইল টুলস",
                    icon = Icons.Default.Apps,
                    isSelected = currentTab == MainTab.TOOLS,
                    goldBorder = goldBorder,
                    onClick = {
                        onNavigateTab(MainTab.TOOLS)
                        onCloseDrawer()
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 3. BOTTOM PREMIER PRO BANNER BUTTON
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Brush.horizontalGradient(listOf(Color(0x55FFD54F), Color(0x33FFB300))))
                .border(1.2.dp, goldBorder, RoundedCornerShape(16.dp))
                .clickable {
                    onOpenPremium()
                    onCloseDrawer()
                }
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.WorkspacePremium,
                        contentDescription = null,
                        tint = Color(0xFFFFD54F),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "PREMIER PRO মেম্বারশিপ",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFD54F)
                        )
                        Text(
                            text = "বিকাশ/নগদ পেমেন্ট ও আনলিমিটেড ভয়েস",
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        }
    }
}

// LARGE GLASSY BUTTON ITEM with Single Icon, Bold Text, and Click Bounce Animation
@Composable
private fun GlassyDrawerButton(
    title: String,
    subtitle: String,
    icon: ImageVector,
    isSelected: Boolean,
    goldBorder: Brush,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scaleAnim by animateFloatAsState(targetValue = if (isPressed) 0.95f else 1f, label = "drawer_btn_scale")

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scaleAnim)
            .clip(RoundedCornerShape(14.dp))
            .background(if (isSelected) Color(0x38FFD54F) else Color(0x28122A3C))
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                brush = if (isSelected) goldBorder else Brush.horizontalGradient(listOf(Color(0x3380DEEA), Color(0x2280DEEA))),
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(interactionSource = interactionSource, indication = null) { onClick() }
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Clean Single Icon (No double icon!)
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isSelected) Color(0x44FFD54F) else Color(0x2800E5FF)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = if (isSelected) Color(0xFFFFD54F) else Color(0xFF80DEEA),
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color(0xFFFFD54F) else TextPrimary
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
private fun DrawerSectionHeader(title: String) {
    Text(
        text = title,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp,
        color = Color(0xFFFFD54F),
        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
    )
}
