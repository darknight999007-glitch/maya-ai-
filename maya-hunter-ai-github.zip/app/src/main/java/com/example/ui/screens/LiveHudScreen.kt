package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PictureInPicture
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ChatMessage
import com.example.data.model.MessageSender
import com.example.service.MayaFloatingService
import com.example.ui.MayaViewModel
import com.example.ui.components.CosmicOrbCanvas
import com.example.ui.components.DateAgendaModal
import com.example.ui.components.EnergyModal
import com.example.ui.components.InteractiveCharacterView
import com.example.ui.components.JournalModal
import com.example.ui.components.LicenseActivationModal
import com.example.ui.components.MoodPersonaModal
import com.example.ui.components.MusicPlayerModal
import com.example.ui.components.PermissionsHubModal
import com.example.ui.components.PremiumSubscriptionModal
import com.example.ui.components.StudyModal
import com.example.ui.components.UserProfileModal
import com.example.ui.components.WeatherDetailSheet
import com.example.ui.theme.MayaCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun LiveHudScreen(
    viewModel: MayaViewModel,
    onOpenDrawer: () -> Unit,
    onOpenSetupModal: () -> Unit,
    modifier: Modifier = Modifier
) {
    val persona by viewModel.currentPersona.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.voiceEngine.isSpeaking.collectAsStateWithLifecycle()
    val isListening by viewModel.voiceEngine.isListening.collectAsStateWithLifecycle()
    val waveformLevel by viewModel.voiceEngine.audioWaveformLevel.collectAsStateWithLifecycle()
    val conversation by viewModel.conversation.collectAsStateWithLifecycle()
    val isThinking by viewModel.isThinking.collectAsStateWithLifecycle()
    val subscriptionState by viewModel.subscriptionState.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()

    var textInput by remember { mutableStateOf("") }
    val context = LocalContext.current

    // Toggle between Animated 3D Cosmic Orb & Live 3D Character
    var showAvatarMode by remember { mutableStateOf(false) }

    // Active Feature Modals
    var isProfileModalOpen by remember { mutableStateOf(false) }
    var isMusicModalOpen by remember { mutableStateOf(false) }
    var isStudyModalOpen by remember { mutableStateOf(false) }
    var isJournalModalOpen by remember { mutableStateOf(false) }
    var isWeatherSheetOpen by remember { mutableStateOf(false) }
    var isDateModalOpen by remember { mutableStateOf(false) }
    var isMoodModalOpen by remember { mutableStateOf(false) }
    var isEnergyModalOpen by remember { mutableStateOf(false) }
    var isLicenseModalOpen by remember { mutableStateOf(false) }
    var isPremiumModalOpen by remember { mutableStateOf(false) }
    var isPermissionsModalOpen by remember { mutableStateOf(false) }

    // Floating Full Conversation Overlay
    var isConversationOverlayOpen by remember { mutableStateOf(false) }

    // Latest Maya speech message for prominent display
    val latestMayaMsg = conversation.lastOrNull { it.sender == MessageSender.MAYA }

    val hasMicPerm = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    val micLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.voiceEngine.startListening()
        }
    }

    // Golden gradient for borders & buttons
    val goldAmberBorder = remember {
        Brush.horizontalGradient(
            listOf(Color(0xFFFFD54F), Color(0xFFFFB300), Color(0xFFFF8F00), Color(0xFFFFD54F))
        )
    }

    // Deep space obsidian background
    val backgroundBrush = remember {
        Brush.verticalGradient(
            colors = listOf(
                Color(0xFF040A12),
                Color(0xFF06141D),
                Color(0xFF081C26),
                Color(0xFF0A1F2B),
                Color(0xFF0C1822)
            )
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(backgroundBrush)
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val screenHeight = maxHeight
            val isCompact = screenHeight < 620.dp

            // Single unified, non-scrolling full-screen layout ("ফুল পর্দায় থাকবে নিচে কোন মিসকল হবে না")
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp, vertical = if (isCompact) 4.dp else 8.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // 1. TOP HEADER (☰  Maya  🛡️ 🔔)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onOpenDrawer,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .testTag("open_drawer_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Menu Drawer",
                            tint = TextPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Text(
                        text = "Maya",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // User Profile Icon (User Profile Panel - Requirement 2)
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color(0x33FFD54F))
                                .border(1.2.dp, Color(0xFFFFD54F), CircleShape)
                                .clickable { isProfileModalOpen = true }
                                .testTag("user_profile_header_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountCircle,
                                contentDescription = "User Profile",
                                tint = Color(0xFFFFD54F),
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        IconButton(
                            onClick = { isPermissionsModalOpen = true },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = "Permissions Hub",
                                tint = Color(0xFFFFD54F),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        IconButton(
                            onClick = onOpenSetupModal,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("open_notifications_button")
                        ) {
                            Box {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = "Settings",
                                    tint = Color(0xFF90CAF9),
                                    modifier = Modifier.size(22.dp)
                                )
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(MayaCyan)
                                        .align(Alignment.TopEnd)
                                )
                            }
                        }
                    }
                }

                // 2. PREMIER PRO BANNER (বিকাশ/নগদ প্ল্যান, আনলিমিটেড ভয়েস ও ৩ দিনের ফ্রি ট্রায়াল)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    Color(0x382A1B05),
                                    Color(0x283E2908),
                                    Color(0x381E2E3D)
                                )
                            )
                        )
                        .border(1.5.dp, goldAmberBorder, RoundedCornerShape(20.dp))
                        .clickable { isPremiumModalOpen = true }
                        .padding(horizontal = 12.dp, vertical = if (isCompact) 6.dp else 8.dp)
                        .testTag("premier_pro_banner")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Gold Glowing Crown
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0x44FFD54F)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WorkspacePremium,
                                    contentDescription = null,
                                    tint = Color(0xFFFFD54F),
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Text(
                                    text = "MAYA PREMIER PRO • ৩ দিনের ফ্রি ট্রায়াল",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFFFFD54F)
                                )
                                Text(
                                    text = "বিকাশ/নগদ পেমেন্ট, আনলিমিটেড ভয়েস ও ড্রাইভ ব্যাকআপ",
                                    fontSize = 10.sp,
                                    color = TextSecondary
                                )
                            }
                        }

                        // Gold Upgrade Button
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(Brush.horizontalGradient(listOf(Color(0xFFFFD54F), Color(0xFFFFB300))))
                                .clickable { isPremiumModalOpen = true }
                                .padding(horizontal = 12.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = "প্ল্যান দেখুন",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF04141E)
                            )
                        }
                    }
                }

                // 3. GREETING & FLOATING CONTROLS ROW
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Still up,",
                            fontSize = if (isCompact) 22.sp else 25.sp,
                            fontWeight = FontWeight.Normal,
                            color = TextPrimary
                        )
                        Text(
                            text = userProfile.name,
                            fontSize = if (isCompact) 26.sp else 30.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFFFD54F),
                            lineHeight = if (isCompact) 28.sp else 32.sp
                        )
                        Spacer(modifier = Modifier.height(1.dp))
                        Text(
                            text = "Maya is ready to help you.",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Floating Movable Ball Overlay button
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0x3300E5FF))
                                .border(1.dp, Color(0x6600E5FF), RoundedCornerShape(14.dp))
                                .clickable {
                                    if (Settings.canDrawOverlays(context)) {
                                        if (MayaFloatingService.isRunning) {
                                            viewModel.stopFloatingService()
                                        } else {
                                            viewModel.startFloatingService()
                                        }
                                    } else {
                                        isPermissionsModalOpen = true
                                    }
                                }
                                .padding(horizontal = 8.dp, vertical = 7.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.PictureInPicture,
                                    contentDescription = null,
                                    tint = Color(0xFF00E5FF),
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (MayaFloatingService.isRunning) "বল অন" else "ভাসমান বল",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF00E5FF)
                                )
                            }
                        }

                        // 1 ENERGY Glass Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0x2E163345))
                                .border(1.5.dp, goldAmberBorder, RoundedCornerShape(14.dp))
                                .clickable { isEnergyModalOpen = true }
                                .padding(horizontal = 9.dp, vertical = 7.dp)
                                .testTag("energy_badge")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Diamond,
                                    contentDescription = "Energy",
                                    tint = Color(0xFFFFD54F),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "1 ENERGY",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFFFFD54F)
                                )
                            }
                        }
                    }
                }

                // 4. CENTER HERO: ANIMATED 3D COSMIC ORB (With Avatar Switcher)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(vertical = 2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (showAvatarMode) {
                        InteractiveCharacterView(
                            isSpeaking = isSpeaking,
                            isListening = isListening,
                            waveformLevel = waveformLevel,
                            persona = persona,
                            onCharacterClick = {
                                if (isSpeaking) viewModel.interruptSpeaking()
                                else {
                                    if (!hasMicPerm) {
                                        micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    } else {
                                        viewModel.voiceEngine.startListening()
                                        isConversationOverlayOpen = true
                                    }
                                }
                            }
                        )
                    } else {
                        // The animated 3D Cosmic Orb ("ভিতরে গোল আকারে বলের মতো দেখা যাচ্ছে সেটা যেন এনিমেশন টাইপের হয়")
                        CosmicOrbCanvas(
                            isSpeaking = isSpeaking,
                            isListening = isListening,
                            waveformLevel = waveformLevel,
                            onClick = {
                                if (isSpeaking) {
                                    viewModel.interruptSpeaking()
                                } else {
                                    if (!hasMicPerm) {
                                        micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    } else {
                                        viewModel.voiceEngine.startListening()
                                        isConversationOverlayOpen = true
                                    }
                                }
                            }
                        )
                    }

                    // Top-right Sleek Mode Switcher Pill (Orb / Avatar)
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0x550B1B26))
                            .border(1.dp, Color(0x4480DEEA), RoundedCornerShape(16.dp))
                            .clickable { showAvatarMode = !showAvatarMode }
                            .padding(horizontal = 9.dp, vertical = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (showAvatarMode) Icons.Default.Public else Icons.Default.Person,
                                contentDescription = "Toggle Mode",
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (showAvatarMode) "Orb Mode" else "Avatar Mode",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF00E5FF)
                            )
                        }
                    }

                    // Bottom Floating Spoken Response Indicator when Speaking
                    if (isSpeaking && latestMayaMsg != null) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth(0.94f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xEB0A1822))
                                .border(1.5.dp, Color(0x8800E5FF), RoundedCornerShape(14.dp))
                                .clickable { isConversationOverlayOpen = true }
                                .padding(horizontal = 12.dp, vertical = 7.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.GraphicEq,
                                        contentDescription = null,
                                        tint = Color(0xFF00E5FF),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = latestMayaMsg.text,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary,
                                        maxLines = 1
                                    )
                                }
                                Text(
                                    text = "ট্যাপ করুন",
                                    fontSize = 11.sp,
                                    color = Color(0xFF80DEEA),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // 5. BOTTOM FROSTED GLASS CONSOLE (Buttons, Status Cards & Search Bar)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(22.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(0x40142938),
                                    Color(0x600C1B26),
                                    Color(0x8008141D)
                                )
                            )
                        )
                        .border(1.dp, Color(0x3380DEEA), RoundedCornerShape(22.dp))
                        .padding(horizontal = 8.dp, vertical = if (isCompact) 6.dp else 8.dp),
                    verticalArrangement = Arrangement.spacedBy(if (isCompact) 5.dp else 7.dp)
                ) {
                    // A) THREE FROSTED PILL BUTTONS (Music, Study, Journal) with Golden Light & Click Bounces
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AnimatedPillButton(
                            title = "Music",
                            icon = Icons.Default.MusicNote,
                            goldBorder = goldAmberBorder,
                            modifier = Modifier.weight(1f),
                            onClick = { isMusicModalOpen = true }
                        )
                        AnimatedPillButton(
                            title = "Study",
                            icon = Icons.Default.School,
                            goldBorder = goldAmberBorder,
                            modifier = Modifier.weight(1f),
                            onClick = { isStudyModalOpen = true }
                        )
                        AnimatedPillButton(
                            title = "Journal",
                            icon = Icons.Default.Edit,
                            goldBorder = goldAmberBorder,
                            modifier = Modifier.weight(1f),
                            onClick = { isJournalModalOpen = true }
                        )
                    }

                    // B) THREE GLASS STATUS CARDS (Weather, Datey, Mood) with Golden Highlights
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Card 1: Weather (26° Clear)
                        AnimatedStatusCard(
                            header = "Weather",
                            headerIcon = Icons.Default.WbSunny,
                            mainValue = "26°",
                            subText = "Clear",
                            icon = Icons.Default.WbSunny,
                            iconTint = Color(0xFFFFB300),
                            goldBorder = goldAmberBorder,
                            modifier = Modifier.weight(1f),
                            onClick = { isWeatherSheetOpen = true }
                        )

                        // Card 2: Datey (2 Fri, Oct)
                        AnimatedStatusCard(
                            header = "Datey",
                            headerIcon = Icons.Default.CalendarMonth,
                            mainValue = "2",
                            subText = "Fri, Oct",
                            icon = Icons.Default.DateRange,
                            iconTint = Color(0xFFFF5252),
                            goldBorder = goldAmberBorder,
                            modifier = Modifier.weight(1f),
                            onClick = { isDateModalOpen = true }
                        )

                        // Card 3: Mood (Warm All good)
                        AnimatedStatusCard(
                            header = "Mood",
                            headerIcon = Icons.Default.Favorite,
                            mainValue = "Warm",
                            subText = "All good",
                            icon = Icons.Default.WbSunny,
                            iconTint = Color(0xFFFF9800),
                            goldBorder = goldAmberBorder,
                            modifier = Modifier.weight(1f),
                            onClick = { isMoodModalOpen = true }
                        )
                    }

                    // C) SEARCH / ASK BAR (🔍 Ask Maya anything... ➤)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(22.dp))
                            .background(Color(0x330B1C26))
                            .border(1.5.dp, Color(0x5526C6DA), RoundedCornerShape(22.dp))
                            .padding(horizontal = 8.dp, vertical = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                tint = Color(0xFF80DEEA),
                                modifier = Modifier.size(19.dp)
                            )

                            OutlinedTextField(
                                value = textInput,
                                onValueChange = { textInput = it },
                                placeholder = {
                                    Text(
                                        "Ask Maya anything / অ্যাপ খুলতে বলুন...",
                                        fontSize = 12.sp,
                                        color = Color(0xFF78909C)
                                    )
                                },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                keyboardActions = KeyboardActions(
                                    onSend = {
                                        if (textInput.isNotBlank()) {
                                            viewModel.processVoiceCommand(textInput.trim())
                                            textInput = ""
                                            isConversationOverlayOpen = true
                                        }
                                    }
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color.Transparent,
                                    unfocusedBorderColor = Color.Transparent,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary,
                                    cursorColor = Color(0xFF26C6DA)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("home_search_input")
                            )

                            IconButton(
                                onClick = {
                                    if (textInput.isNotBlank()) {
                                        viewModel.processVoiceCommand(textInput.trim())
                                        textInput = ""
                                        isConversationOverlayOpen = true
                                    }
                                },
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "Send",
                                    tint = Color(0xFF80DEEA),
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 6. LIVE CONVERSATION OVERLAY SHEET (কথোপকথনের তালিকা ও প্রমিনেন্ট বড় লেখা)
        AnimatedVisibility(
            visible = isConversationOverlayOpen,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            ConversationFloatingSheet(
                messages = conversation,
                isThinking = isThinking,
                onClose = { isConversationOverlayOpen = false },
                onReplayAudio = { viewModel.replayMessage(it) },
                onCopy = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Maya Message", it.text))
                }
            )
        }
    }

    // Interactive Modals Triggered by all UI Buttons
    if (isProfileModalOpen) {
        UserProfileModal(
            profile = userProfile,
            onDismiss = { isProfileModalOpen = false },
            onSaveProfile = { name, avatarId ->
                viewModel.updateProfile(name, avatarId)
            },
            onToggleDrive = { enabled ->
                viewModel.toggleDriveSync(enabled)
            },
            onLogout = {
                viewModel.logout()
                isProfileModalOpen = false
            }
        )
    }

    if (isPremiumModalOpen) {
        PremiumSubscriptionModal(
            subscriptionState = subscriptionState,
            onDismiss = { isPremiumModalOpen = false },
            onSubmitPayment = { method, trxId, plan ->
                viewModel.submitPayment(method, trxId, plan)
            },
            onAdminApprove = {
                viewModel.approveProSubscription()
            },
            onToggleGoogleDrive = { connected ->
                viewModel.toggleGoogleDrive(connected)
            }
        )
    }

    if (isPermissionsModalOpen) {
        PermissionsHubModal(
            hasMicPermission = hasMicPerm,
            onDismiss = { isPermissionsModalOpen = false },
            onRequestMic = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
        )
    }

    if (isMusicModalOpen) {
        MusicPlayerModal(
            onDismiss = { isMusicModalOpen = false },
            onCommand = { cmd -> viewModel.processVoiceCommand(cmd) }
        )
    }

    if (isStudyModalOpen) {
        StudyModal(
            onDismiss = { isStudyModalOpen = false },
            onAskTopic = { topic ->
                viewModel.processVoiceCommand(topic)
                isConversationOverlayOpen = true
            }
        )
    }

    if (isJournalModalOpen) {
        JournalModal(
            onDismiss = { isJournalModalOpen = false },
            onSaveEntry = { entry ->
                viewModel.addMemory("Personal Reflection", entry, "Journal")
                viewModel.processVoiceCommand("Save journal memory: $entry")
                isConversationOverlayOpen = true
            }
        )
    }

    if (isWeatherSheetOpen) {
        WeatherDetailSheet(
            onDismiss = { isWeatherSheetOpen = false },
            onVoiceWeather = {
                viewModel.processVoiceCommand("আজকের বিস্তারিত আবহাওয়া রিপোর্ট বলো")
                isConversationOverlayOpen = true
            }
        )
    }

    if (isDateModalOpen) {
        DateAgendaModal(
            onDismiss = { isDateModalOpen = false },
            onDailyBriefing = {
                viewModel.processVoiceCommand("Run my morning daily briefing")
                isConversationOverlayOpen = true
            }
        )
    }

    if (isMoodModalOpen) {
        MoodPersonaModal(
            currentPersona = persona,
            onSelectPersona = { newPersona -> viewModel.setPersona(newPersona) },
            onDismiss = { isMoodModalOpen = false }
        )
    }

    if (isEnergyModalOpen) {
        EnergyModal(
            onDismiss = { isEnergyModalOpen = false },
            onBoostEnergy = {
                viewModel.processVoiceCommand("Recharge compute boost and check system health")
                isConversationOverlayOpen = true
            }
        )
    }

    if (isLicenseModalOpen) {
        LicenseActivationModal(
            onDismiss = { isLicenseModalOpen = false },
            onActivate = { code ->
                viewModel.processVoiceCommand("License activated with code $code: unlimited talk unlocked")
                isConversationOverlayOpen = true
            }
        )
    }
}

// ANIMATED FROSTED PILL BUTTON with golden glow & click bounce
@Composable
private fun AnimatedPillButton(
    title: String,
    icon: ImageVector,
    goldBorder: Brush,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scaleAnim by animateFloatAsState(targetValue = if (isPressed) 0.94f else 1f, label = "pill_scale")

    Box(
        modifier = modifier
            .scale(scaleAnim)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x38102A38))
            .border(1.2.dp, goldBorder, RoundedCornerShape(16.dp))
            .clickable(interactionSource = interactionSource, indication = null) { onClick() }
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = Color(0xFFFFD54F),
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }
    }
}

// ANIMATED STATUS CARD with golden light & click bounce
@Composable
private fun AnimatedStatusCard(
    header: String,
    headerIcon: ImageVector,
    mainValue: String,
    subText: String,
    icon: ImageVector,
    iconTint: Color,
    goldBorder: Brush,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scaleAnim by animateFloatAsState(targetValue = if (isPressed) 0.94f else 1f, label = "card_scale")

    Box(
        modifier = modifier
            .scale(scaleAnim)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x3D102836))
            .border(1.2.dp, goldBorder, RoundedCornerShape(16.dp))
            .clickable(interactionSource = interactionSource, indication = null) { onClick() }
            .padding(9.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = header,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFFFFD54F)
                )
                Icon(
                    imageVector = headerIcon,
                    contentDescription = null,
                    tint = Color(0xFFFFD54F),
                    modifier = Modifier.size(12.dp)
                )
            }

            Spacer(modifier = Modifier.height(3.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = mainValue,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimary
                    )
                    Text(
                        text = subText,
                        fontSize = 10.sp,
                        color = Color(0xFFB0BEC5)
                    )
                }

                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

// FLOATING LIVE CONVERSATION SHEET with large, high-contrast attractive text
@Composable
private fun ConversationFloatingSheet(
    messages: List<ChatMessage>,
    isThinking: Boolean,
    onClose: () -> Unit,
    onReplayAudio: (ChatMessage) -> Unit,
    onCopy: (ChatMessage) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xF70A1824)),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(Color(0xFFFFD54F), Color(0xFF26C6DA)))),
        modifier = Modifier
            .fillMaxWidth()
            .height(410.dp)
            .padding(horizontal = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00E5FF))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "MAYA VOICE & TEXT (কথোপকথন তালিকা)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = Color(0xFF00E5FF)
                    )
                }

                IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages.takeLast(12)) { msg ->
                    val isUser = msg.sender == MessageSender.USER
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isUser) Color(0x3326C6DA) else Color(0x281B3C52))
                            .border(1.2.dp, if (isUser) Color(0x5526C6DA) else Color(0x55FFD54F), RoundedCornerShape(14.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isUser) "You (আপনি)" else "${msg.persona.title} (ভয়েস ও লিখিত)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isUser) Color(0xFF80DEEA) else Color(0xFFFFD54F)
                                )
                                if (!isUser) {
                                    Row {
                                        IconButton(onClick = { onReplayAudio(msg) }, modifier = Modifier.size(26.dp)) {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                                contentDescription = "Replay",
                                                tint = Color(0xFF80DEEA),
                                                modifier = Modifier.size(17.dp)
                                            )
                                        }
                                        IconButton(onClick = { onCopy(msg) }, modifier = Modifier.size(26.dp)) {
                                            Icon(
                                                imageVector = Icons.Default.ContentCopy,
                                                contentDescription = "Copy",
                                                tint = TextMuted,
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            // Large, clear, attractive typography
                            Text(
                                text = msg.text,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Normal,
                                color = TextPrimary,
                                lineHeight = 21.sp
                            )
                            if (msg.executedAction != null) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "⚡ ${msg.executedAction}",
                                    fontSize = 11.sp,
                                    color = Color(0xFF80DEEA),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                if (isThinking) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(8.dp)) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color(0xFF00E5FF), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "মায়া ভাবছে এবং উত্তর প্রস্তুত করছে...",
                                fontSize = 13.sp,
                                color = TextSecondary,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }
}
