package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MayaPersona
import com.example.ui.theme.MayaBorder
import com.example.ui.theme.MayaCrimson
import com.example.ui.theme.MayaCrimsonDark
import com.example.ui.theme.MayaCyan
import com.example.ui.theme.MayaDarkBg
import com.example.ui.theme.PersonaFridayColor
import com.example.ui.theme.PersonaMayaColor
import com.example.ui.theme.PersonaVenomColor
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.sin

@Composable
fun MayaWaveformOrb(
    isSpeaking: Boolean,
    isListening: Boolean,
    waveformLevel: Float,
    persona: MayaPersona,
    onOrbClick: () -> Unit,
    onInterruptClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_pulse")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isSpeaking || isListening) 700 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val ringRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ring_rotation"
    )

    val primaryAccent = when (persona) {
        MayaPersona.MAYA -> PersonaMayaColor
        MayaPersona.FRIDAY -> PersonaFridayColor
        MayaPersona.VENOM -> PersonaVenomColor
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Glowing Orb Container
        Box(
            modifier = Modifier
                .size(200.dp)
                .clickable { onOrbClick() }
                .testTag("maya_core_orb"),
            contentAlignment = Alignment.Center
        ) {
            // Background Canvas for glowing pulse rings
            Canvas(modifier = Modifier.size(200.dp)) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val baseRadius = size.width / 3.4f
                val activeRadius = baseRadius * (if (isSpeaking || isListening) pulseScale else 1.0f)

                // Outer ambient glow
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            primaryAccent.copy(alpha = if (isSpeaking || isListening) 0.35f else 0.15f),
                            Color.Transparent
                        ),
                        center = center,
                        radius = size.width / 2f
                    ),
                    center = center,
                    radius = size.width / 2f
                )

                // Concentric dynamic rings
                drawCircle(
                    color = primaryAccent.copy(alpha = 0.3f),
                    center = center,
                    radius = activeRadius * 1.35f,
                    style = Stroke(width = 1.5.dp.toPx())
                )

                drawCircle(
                    color = primaryAccent.copy(alpha = 0.6f),
                    center = center,
                    radius = activeRadius * 1.15f,
                    style = Stroke(width = 2.dp.toPx())
                )

                // Central Core
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            primaryAccent,
                            MayaCrimsonDark,
                            MayaDarkBg
                        ),
                        center = center,
                        radius = activeRadius
                    ),
                    center = center,
                    radius = activeRadius
                )
            }

            // Center Content: Icon + Status text
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = if (isListening) Icons.Default.Mic else Icons.Default.GraphicEq,
                    contentDescription = "Maya Status",
                    tint = TextPrimary,
                    modifier = Modifier.size(38.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = when {
                        isSpeaking -> "Speaking (24 kHz)"
                        isListening -> "Listening (16 kHz)"
                        else -> "Live Engine Idle"
                    },
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary.copy(alpha = 0.9f)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Sound Waveform Bars (Representing the brochure waveform)
        WaveformSpectrum(
            level = if (isSpeaking || isListening) (waveformLevel * pulseScale).coerceIn(0.2f, 1.0f) else 0.15f,
            accentColor = primaryAccent,
            modifier = Modifier.padding(horizontal = 24.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Interrupt (Barge-In) Button if speaking
        if (isSpeaking) {
            OutlinedButton(
                onClick = onInterruptClick,
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = MayaCrimson
                ),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .border(1.dp, MayaCrimson, RoundedCornerShape(20.dp))
                    .testTag("interrupt_button")
            ) {
                Icon(
                    imageVector = Icons.Default.StopCircle,
                    contentDescription = "Interrupt",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Interrupt Her (Barge-In)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun WaveformSpectrum(
    level: Float,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(28.dp)
    ) {
        val barCount = 27
        val barWidth = 3.dp.toPx()
        val spacing = (size.width - (barCount * barWidth)) / (barCount - 1)
        val centerY = size.height / 2f

        for (i in 0 until barCount) {
            val normalizedIdx = (i - barCount / 2f) / (barCount / 2f)
            val bellCurve = 1.0f - (normalizedIdx * normalizedIdx).coerceIn(0f, 0.9f)
            val waveHeight = (size.height * 0.9f * level * bellCurve * (0.4f + 0.6f * sin((i * 0.7f).toDouble()).toFloat().coerceAtLeast(0.1f))).coerceAtLeast(4f)

            val x = i * (barWidth + spacing)
            drawLine(
                color = if (i % 2 == 0) accentColor else accentColor.copy(alpha = 0.5f),
                start = Offset(x, centerY - waveHeight / 2f),
                end = Offset(x, centerY + waveHeight / 2f),
                strokeWidth = barWidth,
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )
        }
    }
}
