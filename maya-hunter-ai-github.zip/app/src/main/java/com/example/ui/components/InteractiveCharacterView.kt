package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.MayaPersona
import com.example.ui.theme.MayaBorder
import com.example.ui.theme.MayaCrimson
import com.example.ui.theme.MayaCyan
import com.example.ui.theme.MayaDarkBg
import com.example.ui.theme.MayaEmerald
import com.example.ui.theme.MayaSurface
import com.example.ui.theme.PersonaFridayColor
import com.example.ui.theme.PersonaMayaColor
import com.example.ui.theme.PersonaVenomColor
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun InteractiveCharacterView(
    isSpeaking: Boolean,
    isListening: Boolean,
    waveformLevel: Float,
    persona: MayaPersona,
    onCharacterClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "character_life")

    // Idle breathing & gentle floating vertical offset
    val breathingY by infiniteTransition.animateFloat(
        initialValue = -5f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathing"
    )

    // Subtle natural body sway
    val bodySwayAngle by infiniteTransition.animateFloat(
        initialValue = -1.5f,
        targetValue = 1.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sway"
    )

    // Head and neck tilt when speaking or listening
    val headTiltAngle by infiniteTransition.animateFloat(
        initialValue = if (isSpeaking) -3.5f else -1f,
        targetValue = if (isSpeaking) 3.5f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (isSpeaking) 600 else 2200,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "head_tilt"
    )

    // Hand & arm subtle gesture offset when speaking
    val gestureOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = if (isSpeaking) 8f else 2f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (isSpeaking) 500 else 1800,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "arm_gesture"
    )

    // Dynamic mouth / lip-sync movement scaling with speech waveform
    val mouthScale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.4f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "mouth_lipsync"
    )

    val auraGlowScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "aura_glow"
    )

    val personaAccent = when (persona) {
        MayaPersona.MAYA -> PersonaMayaColor
        MayaPersona.FRIDAY -> PersonaFridayColor
        MayaPersona.VENOM -> PersonaVenomColor
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(340.dp)
            .clickable { onCharacterClick() }
            .testTag("interactive_maya_character"),
        contentAlignment = Alignment.Center
    ) {
        // Glowing Ambient Backdrop Aura
        Box(
            modifier = Modifier
                .size(240.dp)
                .scale(if (isSpeaking || isListening) auraGlowScale else 1f)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            personaAccent.copy(alpha = if (isSpeaking) 0.35f else 0.18f),
                            MayaCyan.copy(alpha = 0.1f),
                            Color.Transparent
                        )
                    )
                )
        )

        // Animated Character Container (Moving Body, Neck & Arms)
        Box(
            modifier = Modifier
                .offset { IntOffset(0, breathingY.roundToInt()) }
                .rotate(if (isSpeaking) headTiltAngle else bodySwayAngle)
                .scale(if (isSpeaking) (1.0f + (waveformLevel * 0.05f)) else 1.0f),
            contentAlignment = Alignment.Center
        ) {
            // Character Image
            Image(
                painter = painterResource(id = R.drawable.maya_character),
                contentDescription = "Maya AI Live Character",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .height(310.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .shadow(elevation = 12.dp, shape = RoundedCornerShape(24.dp))
            )

            // Dynamic Lip-Sync & Face Articulation Overlay
            // Positioned near the character's face (top 28% of the image)
            if (isSpeaking) {
                Box(
                    modifier = Modifier
                        .offset(y = (-75).dp)
                        .size(34.dp)
                        .scale(mouthScale * (0.8f + waveformLevel * 0.6f))
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    personaAccent.copy(alpha = 0.75f),
                                    MayaCrimson.copy(alpha = 0.3f),
                                    Color.Transparent
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .width((8 + waveformLevel * 10).dp)
                            .height((4 + waveformLevel * 10).dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.White.copy(alpha = 0.9f))
                    )
                }
            }

            // Hand Gesture Wave pulse indicator when speaking
            if (isSpeaking) {
                Box(
                    modifier = Modifier
                        .offset(x = 55.dp, y = gestureOffset.dp)
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(MayaCyan.copy(alpha = 0.4f))
                )
            }
        }

        // Floating Status Pills over the Character (Matching Screenshot 1)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Status Chip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(MayaSurface.copy(alpha = 0.85f))
                        .border(1.dp, MayaBorder, RoundedCornerShape(16.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isSpeaking) MayaEmerald else if (isListening) MayaCyan else personaAccent)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = when {
                                isSpeaking -> "Speaking (কথা বলছে...)"
                                isListening -> "Listening (শুনছে...)"
                                else -> "Ready (সজাগ)"
                            },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                }

                // Mood Indicator (From Screenshot 1: '💖 Happy')
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(MayaSurface.copy(alpha = 0.85f))
                        .border(1.dp, MayaBorder, RoundedCornerShape(16.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isSpeaking) "✨ Active" else "💖 Warm & Happy",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = personaAccent
                    )
                }
            }

            // Bottom Audio Pulse Waveform directly beneath character
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isSpeaking || isListening) {
                    WaveformSpectrum(
                        level = if (isSpeaking) (waveformLevel * 1.2f).coerceIn(0.3f, 1.0f) else 0.4f,
                        accentColor = personaAccent,
                        modifier = Modifier.width(180.dp)
                    )
                }
            }
        }
    }
}
