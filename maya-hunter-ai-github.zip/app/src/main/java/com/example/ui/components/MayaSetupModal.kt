package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.ui.theme.MayaBorder
import com.example.ui.theme.MayaCrimson
import com.example.ui.theme.MayaCyan
import com.example.ui.theme.MayaDarkBg
import com.example.ui.theme.MayaEmerald
import com.example.ui.theme.MayaSurface
import com.example.ui.theme.MayaSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MayaSetupDialog(
    onDismiss: () -> Unit,
    onSaveKey: (String) -> Unit,
    onAllowAllPermissions: () -> Unit,
    initialKey: String = ""
) {
    var step by remember { mutableIntStateOf(1) }
    var apiKeyInput by remember { mutableStateOf(initialKey) }
    var keyStatus by remember { mutableStateOf("Ready") }

    var micAllowed by remember { mutableStateOf(false) }
    var notifAllowed by remember { mutableStateOf(false) }
    var cameraAllowed by remember { mutableStateOf(false) }
    var callsAllowed by remember { mutableStateOf(false) }
    var contactsAllowed by remember { mutableStateOf(false) }
    var smsAllowed by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(MayaDarkBg),
            color = MayaDarkBg
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header (Matching Screenshot 4 & 5)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.maya_avatar),
                        contentDescription = "Maya Logo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Set up Maya",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = if (step == 1) "Step 1 of 3 · Gemini Key" else "Step 2 of 3 · Phone Permissions",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Progress Step Bars
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(4.dp)
                            .clip(CircleShape)
                            .background(MayaCyan)
                    )
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(4.dp)
                            .clip(CircleShape)
                            .background(if (step >= 2) MayaCyan else MayaBorder)
                    )
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(4.dp)
                            .clip(CircleShape)
                            .background(if (step >= 3) MayaCyan else MayaBorder)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                if (step == 1) {
                    // STEP 1: Add your Gemini Key (Screenshot 5)
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item {
                            Text(
                                text = "Add your Gemini key",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Maya's voice and brain run on Google's Gemini. Without a key she cannot hear you or answer. The key is free and takes about a minute.",
                                fontSize = 13.sp,
                                color = TextSecondary,
                                lineHeight = 18.sp
                            )
                        }

                        item {
                            InstructionStep(
                                number = "1",
                                text = "Tap \"Get a free key\" — Google AI Studio opens. Sign in with any Google account."
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            InstructionStep(
                                number = "2",
                                text = "Tap \"Create API key\", pick any project, and copy the key."
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            InstructionStep(
                                number = "3",
                                text = "Come back and paste it below — the key itself, not your name or email."
                            )
                        }

                        item {
                            OutlinedButton(
                                onClick = { /* Google AI Studio Link */ },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, MayaBorder, RoundedCornerShape(12.dp))
                            ) {
                                Icon(imageVector = Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, tint = MayaCyan, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Get a free key", fontSize = 14.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                            }
                        }

                        item {
                            OutlinedTextField(
                                value = apiKeyInput,
                                onValueChange = { apiKeyInput = it },
                                placeholder = { Text("Paste API Key here...", color = TextMuted) },
                                trailingIcon = {
                                    Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = MayaCyan)
                                },
                                singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = MayaCyan,
                                    unfocusedBorderColor = MayaBorder,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        item {
                            OutlinedButton(
                                onClick = {
                                    keyStatus = if (apiKeyInput.isNotBlank()) "Key Verified ✓" else "Key is empty"
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, MayaBorder, RoundedCornerShape(12.dp))
                            ) {
                                Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = MayaEmerald, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(if (keyStatus == "Ready") "Test key" else keyStatus, fontSize = 14.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                            }
                        }

                        item {
                            Text(
                                text = "The key is free. It is stored encrypted and used only to run Maya for you.",
                                fontSize = 12.sp,
                                color = TextMuted,
                                lineHeight = 16.sp
                            )
                        }
                    }

                    // Bottom Action for Step 1
                    Column {
                        Button(
                            onClick = {
                                onSaveKey(apiKeyInput)
                                step = 2
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MayaCyan),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                        ) {
                            Text("Save & continue", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MayaDarkBg)
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = MayaDarkBg, modifier = Modifier.size(18.dp))
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Added a key on this phone before? Skip",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .clickable { step = 2 }
                        )
                    }
                } else {
                    // STEP 2: Let Maya use your phone (Screenshot 4)
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Text(
                                text = "Let Maya use your phone",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "One tap — Android asks for each in turn. Only the microphone is required; the rest make her useful.",
                                fontSize = 13.sp,
                                color = TextSecondary,
                                lineHeight = 18.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                        }

                        item {
                            PermissionItemCard(
                                title = "Microphone",
                                description = "So you can talk to Maya. Required.",
                                icon = Icons.Default.Mic,
                                isAllowed = micAllowed,
                                onToggle = { micAllowed = !micAllowed }
                            )
                        }
                        item {
                            PermissionItemCard(
                                title = "Notifications",
                                description = "Maya's own notification, which keeps her running in the background.",
                                icon = Icons.Default.Notifications,
                                isAllowed = notifAllowed,
                                onToggle = { notifAllowed = !notifAllowed }
                            )
                        }
                        item {
                            PermissionItemCard(
                                title = "Camera",
                                description = "So she can take a photo or look at what you point the phone at.",
                                icon = Icons.Default.CameraAlt,
                                isAllowed = cameraAllowed,
                                onToggle = { cameraAllowed = !cameraAllowed }
                            )
                        }
                        item {
                            PermissionItemCard(
                                title = "Phone calls",
                                description = "So she can place a call for you.",
                                icon = Icons.Default.Call,
                                isAllowed = callsAllowed,
                                onToggle = { callsAllowed = !callsAllowed }
                            )
                        }
                        item {
                            PermissionItemCard(
                                title = "Contacts",
                                description = "So a name is enough — she looks up the number.",
                                icon = Icons.Default.Contacts,
                                isAllowed = contactsAllowed,
                                onToggle = { contactsAllowed = !contactsAllowed }
                            )
                        }
                        item {
                            PermissionItemCard(
                                title = "SMS",
                                description = "So she can send a text message and capture bank OTP.",
                                icon = Icons.Default.Sms,
                                isAllowed = smsAllowed,
                                onToggle = { smsAllowed = !smsAllowed }
                            )
                        }
                    }

                    // Bottom Action for Step 2
                    Column {
                        Button(
                            onClick = {
                                micAllowed = true
                                notifAllowed = true
                                cameraAllowed = true
                                callsAllowed = true
                                contactsAllowed = true
                                smsAllowed = true
                                onAllowAllPermissions()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MayaCyan),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = MayaDarkBg, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Allow all", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MayaDarkBg)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedButton(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .border(1.dp, MayaBorder, RoundedCornerShape(12.dp))
                        ) {
                            Text("Continue", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(16.dp))
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Continue unlocks once the microphone is allowed.",
                            fontSize = 11.sp,
                            color = TextMuted,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun InstructionStep(
    number: String,
    text: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(MayaCyan.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = number,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MayaCyan
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = text,
            fontSize = 12.sp,
            color = TextSecondary,
            lineHeight = 16.sp
        )
    }
}

@Composable
private fun PermissionItemCard(
    title: String,
    description: String,
    icon: ImageVector,
    isAllowed: Boolean,
    onToggle: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MayaSurface),
        shape = RoundedCornerShape(14.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(MayaBorder)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggle() }
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(MayaSurfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = if (isAllowed) MayaEmerald else MayaCyan, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = description, fontSize = 11.sp, color = TextSecondary, lineHeight = 15.sp)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isAllowed) MayaEmerald.copy(alpha = 0.2f) else MayaCrimson.copy(alpha = 0.15f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = if (isAllowed) "Allowed" else "Pending",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isAllowed) MayaEmerald else MayaCrimson
                )
            }
        }
    }
}
