package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.EntityLog
import com.example.data.local.EntityMacro
import com.example.data.local.EntityMemory
import com.example.data.local.EntityOtp
import com.example.data.local.EntitySubscription
import com.example.data.local.EntityTool
import com.example.data.local.MayaDatabase
import com.example.data.model.AgentFleetMember
import com.example.data.model.CategorySummary
import com.example.data.model.ChatMessage
import com.example.data.model.MayaPersona
import com.example.data.model.MessageSender
import com.example.data.model.PhoneLinkStatus
import com.example.data.model.TimelineItem
import com.example.data.remote.MayaAiEngine
import com.example.data.repository.MayaRepository
import com.example.service.MayaFloatingService
import com.example.util.NetworkMonitor
import com.example.voice.MayaVoiceEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MainTab(val title: String, val icon: String) {
    HUD("Live HUD", "graphic_eq"),
    TOOLS("234 Tools", "apps"),
    PHONE_LINK("Phone Link", "smartphone"),
    FLEET("Agent Fleet", "groups"),
    TIMELINE("12h Schedule", "schedule"),
    STUDIO("Engine / BYOM", "settings")
}

data class UiState(
    val currentTab: MainTab = MainTab.HUD,
    val selectedCategory: String = "All",
    val searchQuery: String = "",
    val activeCodingEngine: String = "Claude Code",
    val codingMode: String = "Visible Mode", // Quiet Mode vs Visible Mode
    val selectedModelEndpoint: String = "Google Gemini Live API",
    val isQrScannerVisible: Boolean = false,
    val isAddMacroVisible: Boolean = false,
    val isDelegateModalVisible: Boolean = false,
    val selectedToolForDetail: EntityTool? = null,
    val statusNotification: String? = null
)

class MayaViewModel(application: Application) : AndroidViewModel(application) {

    private val database = MayaDatabase.getDatabase(application)
    private val repository = MayaRepository(database.mayaDao())
    val voiceEngine = MayaVoiceEngine(application)

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private val networkMonitor = NetworkMonitor(application)
    val isOnline: StateFlow<Boolean> = networkMonitor.isOnline
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), networkMonitor.checkCurrentConnectivity())

    val authManager = com.example.data.auth.MayaAuthManager(application)
    val userProfile: StateFlow<com.example.data.auth.UserProfile> = authManager.userProfile

    val firebaseCoordinator = com.example.firebase.MayaFirebaseCoordinator(application)

    val subscriptionState: StateFlow<EntitySubscription?> = repository.subscriptionState
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentPersona: StateFlow<MayaPersona> = repository.currentPersona
    val phoneLinkState: StateFlow<PhoneLinkStatus> = repository.phoneLinkState
    val agentFleet: StateFlow<List<AgentFleetMember>> = repository.agentFleet

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    private val _conversation = MutableStateFlow(
        listOf(
            ChatMessage(
                sender = MessageSender.MAYA,
                text = "Hello! আমি মায়া—The Hunter AI (v6.0.8)। আমি উইন্ডোজ ডেস্কটপে ২৩৪টি টুল পরিচালনা করি। আপনি যেকোনো কিছু ভয়েসে বা লিখে জিজ্ঞেস করতে পারেন—আমি সরাসরি ভয়েসে কথা বলব এবং এখানে লিখেও দেব!",
                persona = MayaPersona.MAYA,
                executedAction = "Live Voice Engine Active"
            )
        )
    )
    val conversation: StateFlow<List<ChatMessage>> = _conversation.asStateFlow()

    val allTools: StateFlow<List<EntityTool>> = repository.allTools
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredTools: StateFlow<List<EntityTool>> = combine(
        repository.allTools,
        _uiState
    ) { tools, state ->
        tools.filter { tool ->
            val matchesCategory = if (state.selectedCategory == "All") true else tool.category == state.selectedCategory
            val matchesSearch = if (state.searchQuery.isBlank()) true else {
                tool.name.contains(state.searchQuery, ignoreCase = true) ||
                tool.category.contains(state.searchQuery, ignoreCase = true) ||
                tool.examplePrompt.contains(state.searchQuery, ignoreCase = true)
            }
            matchesCategory && matchesSearch
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLogs: StateFlow<List<EntityLog>> = repository.allLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allMemories: StateFlow<List<EntityMemory>> = repository.allMemories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allMacros: StateFlow<List<EntityMacro>> = repository.allMacros
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allOtps: StateFlow<List<EntityOtp>> = repository.allOtps
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categories: List<CategorySummary> = repository.getCategories()
    val timeline: List<TimelineItem> = repository.getTimeline()

    init {
        voiceEngine.onSpeechRecognized = { recognizedText ->
            processVoiceCommand(recognizedText)
        }
    }

    fun selectTab(tab: MainTab) {
        _uiState.value = _uiState.value.copy(currentTab = tab)
    }

    fun selectCategory(category: String) {
        _uiState.value = _uiState.value.copy(selectedCategory = category)
    }

    fun updateSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun setPersona(persona: MayaPersona) {
        repository.setPersona(persona)
        val greetingMsg = ChatMessage(
            sender = MessageSender.MAYA,
            text = persona.greeting,
            persona = persona,
            executedAction = "Persona Switched to ${persona.title}"
        )
        _conversation.value = _conversation.value + greetingMsg
        voiceEngine.speak(persona.greeting, persona)
        showNotification("Persona switched to ${persona.title}")
    }

    fun setCodingEngine(engine: String) {
        _uiState.value = _uiState.value.copy(activeCodingEngine = engine)
        showNotification("Coding engine switched to $engine")
    }

    fun setCodingMode(mode: String) {
        _uiState.value = _uiState.value.copy(codingMode = mode)
        showNotification("Coding mode set to $mode")
    }

    fun setModelEndpoint(endpoint: String) {
        _uiState.value = _uiState.value.copy(selectedModelEndpoint = endpoint)
        showNotification("Universal model switched to $endpoint")
    }

    fun toggleTool(tool: EntityTool) {
        viewModelScope.launch {
            val updated = !tool.isEnabled
            repository.setToolEnabled(tool.id, updated)
            showNotification("${tool.name} ${if (updated) "enabled" else "disabled"}")
        }
    }

    fun toggleCategory(category: String, isEnabled: Boolean) {
        viewModelScope.launch {
            repository.setCategoryEnabled(category, isEnabled)
            showNotification("$category tools ${if (isEnabled) "enabled" else "disabled"}")
        }
    }

    fun toggleDuetMode() {
        repository.toggleDuetMode()
        val isActive = repository.phoneLinkState.value.isDuetModeActive
        val message = if (isActive) {
            "Duet mode active. Desktop Maya and Phone Maya are synchronized."
        } else {
            "Duet mode disconnected."
        }
        val duetMsg = ChatMessage(
            sender = MessageSender.MAYA,
            text = message,
            persona = currentPersona.value,
            executedAction = "Duet Mode Toggle"
        )
        _conversation.value = _conversation.value + duetMsg
        voiceEngine.speak(message, currentPersona.value)
    }

    fun toggleFlashlight() {
        repository.toggleFlashlight()
    }

    fun toggleVoiceCall() {
        repository.toggleVoiceCall()
        val isActive = repository.phoneLinkState.value.isVoiceCallActive
        val text = if (isActive) {
            "Live voice call connected to your Windows desktop. Speak now."
        } else {
            "Call disconnected."
        }
        val callMsg = ChatMessage(
            sender = MessageSender.MAYA,
            text = text,
            persona = currentPersona.value,
            executedAction = "Voice Bridge Session"
        )
        _conversation.value = _conversation.value + callMsg
        voiceEngine.speak(text, currentPersona.value)
    }

    fun simulateNewOtp() {
        viewModelScope.launch {
            val code = (100000..999999).random().toString()
            repository.receiveSimulatedOtp(
                sender = "CHASE-VERIFY",
                code = code,
                message = "$code is your one-time passcode for Desktop access. Synced to Windows clipboard."
            )
            val otpMsg = "New OTP received: $code. Copied to your PC clipboard automatically."
            val replyMsg = ChatMessage(
                sender = MessageSender.MAYA,
                text = otpMsg,
                persona = currentPersona.value,
                executedAction = "Auto Clipboard Beam: $code"
            )
            _conversation.value = _conversation.value + replyMsg
            voiceEngine.speak(otpMsg, currentPersona.value)
            showNotification("OTP $code beamed to PC clipboard")
        }
    }

    fun processVoiceCommand(prompt: String) {
        if (prompt.isBlank()) return
        val persona = currentPersona.value

        // 1. Immediately post the user message into the visible conversation stream
        val userMsg = ChatMessage(
            sender = MessageSender.USER,
            text = prompt.trim()
        )
        _conversation.value = _conversation.value + userMsg
        _isThinking.value = true

        viewModelScope.launch {
            try {
                // 2. Fetch intelligent response via Gemini AI & Automation Controller (Personalized with user's name)
                val currentUserName = authManager.userProfile.value.name
                val (response, outcome) = MayaAiEngine.generateResponse(
                    prompt = prompt,
                    persona = persona,
                    context = getApplication<Application>().applicationContext,
                    userName = currentUserName
                )

                // 3. Post Maya's written response into the visible conversation stream
                val mayaMsg = ChatMessage(
                    sender = MessageSender.MAYA,
                    text = response,
                    persona = persona,
                    executedAction = outcome
                )
                _conversation.value = _conversation.value + mayaMsg

                // 4. Save to session database logs and long-term conversation storage (30-day retention)
                repository.addLog(
                    prompt = prompt,
                    response = response,
                    category = "Voice & Automation",
                    agentUsed = persona.title,
                    outcome = outcome
                )
                repository.saveChatMessage("USER", prompt.trim(), persona.title, null)
                repository.saveChatMessage("MAYA", response, persona.title, outcome)
                repository.cleanOldChatMessages()

                // 5. Speak the response out loud with natural female Text-to-Speech
                voiceEngine.speak(response, persona)
            } catch (e: Exception) {
                val fallbackText = "I processed your request: \"$prompt\"."
                val fallbackMsg = ChatMessage(
                    sender = MessageSender.MAYA,
                    text = fallbackText,
                    persona = persona,
                    executedAction = "Executed on PC"
                )
                _conversation.value = _conversation.value + fallbackMsg
                voiceEngine.speak(fallbackText, persona)
            } finally {
                _isThinking.value = false
            }
        }
    }

    fun replayMessage(message: ChatMessage) {
        voiceEngine.speak(message.text, message.persona)
        showNotification("Speaking voice reply...")
    }

    fun interruptSpeaking() {
        voiceEngine.interrupt()
        showNotification("Barge-in: Maya interrupted")
    }

    fun executeTimelineMilestone(item: TimelineItem) {
        val persona = currentPersona.value

        val userMsg = ChatMessage(
            sender = MessageSender.USER,
            text = item.userPrompt
        )
        val mayaMsg = ChatMessage(
            sender = MessageSender.MAYA,
            text = item.mayaResponse,
            persona = persona,
            executedAction = item.systemOutcome
        )
        _conversation.value = _conversation.value + userMsg + mayaMsg

        viewModelScope.launch {
            repository.addLog(
                prompt = item.userPrompt,
                response = item.mayaResponse,
                category = item.category,
                agentUsed = "Maya 6.0 Core",
                outcome = item.systemOutcome
            )
        }
        voiceEngine.speak(item.mayaResponse, persona)
        showNotification("Executed: ${item.title}")
    }

    fun executeToolOnPc(tool: EntityTool) {
        processVoiceCommand(tool.examplePrompt)
        showNotification("Fired on PC: \"${tool.examplePrompt}\"")
    }

    fun spawnAgent(name: String, mission: String, type: String) {
        repository.spawnNewAgentTask(name, mission, type)
        _uiState.value = _uiState.value.copy(isDelegateModalVisible = false)
        val reply = "Spawned $type: $name in parallel. Task is running in background."
        val agentMsg = ChatMessage(
            sender = MessageSender.MAYA,
            text = reply,
            persona = currentPersona.value,
            executedAction = "Sub-agent $name Allocated"
        )
        _conversation.value = _conversation.value + agentMsg
        voiceEngine.speak(reply, currentPersona.value)
        showNotification("Sub-agent $name dispatched")
    }

    fun advanceAgentProgress(agentId: String) {
        repository.simulateAgentProgress(agentId)
    }

    fun showToolDetail(tool: EntityTool?) {
        _uiState.value = _uiState.value.copy(selectedToolForDetail = tool)
    }

    fun showQrScanner(show: Boolean) {
        _uiState.value = _uiState.value.copy(isQrScannerVisible = show)
    }

    fun showAddMacro(show: Boolean) {
        _uiState.value = _uiState.value.copy(isAddMacroVisible = show)
    }

    fun showDelegateModal(show: Boolean) {
        _uiState.value = _uiState.value.copy(isDelegateModalVisible = show)
    }

    fun saveMacro(title: String, triggerPhrase: String, steps: String) {
        viewModelScope.launch {
            repository.addMacro(title, triggerPhrase, steps)
            _uiState.value = _uiState.value.copy(isAddMacroVisible = false)
            showNotification("Macro '$title' created")
        }
    }

    fun deleteMacro(id: Long) {
        viewModelScope.launch {
            repository.deleteMacro(id)
        }
    }

    fun addMemory(key: String, content: String, category: String) {
        viewModelScope.launch {
            repository.addMemory(key, content, category)
            showNotification("Memory saved locally")
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            repository.deleteMemory(id)
            showNotification("Memory forgotten on command")
        }
    }

    fun submitPayment(method: String, trxId: String, plan: String) {
        viewModelScope.launch {
            repository.submitSubscriptionPayment(method, trxId, plan)
            showNotification("পেমেন্ট সাবমিট হয়েছে ($method - $trxId)")
        }
    }

    fun approveProSubscription() {
        viewModelScope.launch {
            repository.approveSubscription()
            showNotification("প্রিমিয়াম প্রো প্ল্যান সক্রিয় করা হয়েছে!")
        }
    }

    fun toggleGoogleDrive(connected: Boolean) {
        viewModelScope.launch {
            repository.toggleGoogleDriveConnection(connected)
            showNotification(if (connected) "Google Drive ব্যাকআপ যুক্ত হয়েছে" else "Google Drive সংযোগ বিচ্ছিন্ন")
        }
    }

    fun startFloatingService() {
        MayaFloatingService.start(getApplication())
        showNotification("ডিসপ্লেতে ভাসমান বল সক্রিয় হয়েছে")
    }

    fun stopFloatingService() {
        MayaFloatingService.stop(getApplication())
        showNotification("ভাসমান বল নিষ্ক্রিয় করা হয়েছে")
    }

    fun toggleContinuousListening() {
        val current = voiceEngine.isContinuousListening
        voiceEngine.isContinuousListening = !current
        if (!current) {
            voiceEngine.startListening()
            showNotification("হ্যান্ডস-ফ্রি সারাক্ষণ ভয়েস সক্রিয়")
        } else {
            voiceEngine.stopListening()
            showNotification("সারাক্ষণ ভয়েস বন্ধ করা হয়েছে")
        }
    }

    private fun showNotification(msg: String) {
        _uiState.value = _uiState.value.copy(statusNotification = msg)
    }

    fun clearNotification() {
        _uiState.value = _uiState.value.copy(statusNotification = null)
    }

    fun loginWithOtp(phone: String, name: String) {
        authManager.login(phone, name)
        firebaseCoordinator.syncHeartbeat(phone, name)
        val greeting = "হ্যালো $name, আমি আপনার ব্যক্তিগত সহকারী মায়া। আপনার ৩ দিনের পূর্ণ ফ্রি ট্রায়াল সক্রিয় হয়েছে। আমি আপনাকে কীভাবে সাহায্য করতে পারি?"
        val welcomeMsg = ChatMessage(
            sender = MessageSender.MAYA,
            text = greeting,
            persona = currentPersona.value,
            executedAction = "Account Verified: $phone"
        )
        _conversation.value = _conversation.value + welcomeMsg
        voiceEngine.speak(greeting, currentPersona.value)
        showNotification("স্বাগতম $name! ৩ দিনের ফ্রি ট্রায়াল চালু হয়েছে।")
    }

    fun updateProfile(name: String, avatarId: String) {
        authManager.updateProfile(name, avatarId)
        showNotification("প্রোফাইল তথ্য সেভ করা হয়েছে")
    }

    fun toggleDriveSync(enabled: Boolean) {
        authManager.toggleGoogleDrive(enabled)
        toggleGoogleDrive(enabled)
    }

    fun logout() {
        authManager.logout()
        showNotification("লগআউট সম্পন্ন হয়েছে")
    }

    override fun onCleared() {
        super.onCleared()
        voiceEngine.release()
    }
}
