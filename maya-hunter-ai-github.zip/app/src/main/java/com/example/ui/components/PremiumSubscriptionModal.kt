package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddModerator
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.EntitySubscription
import com.example.ui.theme.MayaCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PremiumSubscriptionModal(
    subscriptionState: EntitySubscription?,
    onDismiss: () -> Unit,
    onSubmitPayment: (method: String, trxId: String, plan: String) -> Unit,
    onAdminApprove: () -> Unit,
    onToggleGoogleDrive: (Boolean) -> Unit
) {
    val context = LocalContext.current
    var selectedPlan by remember { mutableStateOf("Monthly Pro (৳299)") }
    var selectedMethod by remember { mutableStateOf("bKash") }
    var trxIdInput by remember { mutableStateOf("") }
    var copyNotice by remember { mutableStateOf<String?>(null) }

    val isPending = subscriptionState?.status == "PENDING"
    val isPro = subscriptionState?.status == "PRO_ACTIVE"
    val isGoogleDriveLinked = subscriptionState?.isGoogleDriveConnected == true

    val goldBorder = Brush.horizontalGradient(
        colors = listOf(Color(0xFFFFD54F), Color(0xFFFFB300), Color(0xFFFF8F00), Color(0xFFFFD54F))
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        containerColor = Color(0xF50A1520),
        shape = RoundedCornerShape(24.dp),
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. Header with Golden Crown Icon
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0x33FFD54F))
                                .border(1.5.dp, Color(0xFFFFD54F), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.WorkspacePremium,
                                contentDescription = null,
                                tint = Color(0xFFFFD54F),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "MAYA PREMIER PRO",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFFFFD54F),
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "প্রিমিয়াম মেম্বারশিপ ও আনলিমিটেড ভয়েস",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    // 3-Day Free Trial Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isPro) Color(0x3300E676) else if (isPending) Color(0x33FFB300) else Color(0x3300E5FF))
                            .border(1.dp, if (isPro) Color(0xFF00E676) else if (isPending) Color(0xFFFFB300) else MayaCyan, RoundedCornerShape(12.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (isPro) "PRO ACTIVE" else if (isPending) "PENDING" else "3-DAY TRIAL",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isPro) Color(0xFF00E676) else if (isPending) Color(0xFFFFB300) else Color(0xFF00E5FF)
                        )
                    }
                }

                // 2. Status Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x2B1A3B4F))
                        .border(1.5.dp, goldBorder, RoundedCornerShape(16.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isPro) Icons.Default.CheckCircle else if (isPending) Icons.Default.HourglassTop else Icons.Default.Star,
                                contentDescription = null,
                                tint = if (isPro) Color(0xFF00E676) else Color(0xFFFFD54F),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = when {
                                    isPro -> "আপনার প্রিমিয়ার প্রো প্ল্যান সক্রিয় রয়েছে!"
                                    isPending -> "পেমেন্ট পেন্ডিং — এডমিন ভেরিফিকেশন চলছে..."
                                    else -> "৩ দিনের ফ্রি ট্রায়াল সক্রিয় রয়েছে"
                                },
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "মেয়াদ শেষ হলে কথা বলা ও অটোমেশন সাময়িক স্থগিত থাকবে। বিকাশ বা নগদে পেমেন্ট করে সক্রিয় রাখুন।",
                            fontSize = 11.sp,
                            color = TextSecondary,
                            lineHeight = 15.sp
                        )
                    }
                }

                // 3. Plan Selection
                Text(
                    text = "সাবস্ক্রিপশন প্ল্যান নির্বাচন করুন:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )

                val plans = listOf(
                    "Monthly Pro (৳299)" to "১ মাস আনলিমিটেড ভয়েস ও ডিভাইস অটোমেশন",
                    "6 Months Pro (৳1,499)" to "৬ মাস আনলিমিটেড + প্রায়োরিটি এআই স্পিড",
                    "Annual VIP (৳2,499)" to "১ বছর পূর্ণ সেবা + গুগল ড্রাইভ লাইফটাইম ব্যাকআপ"
                )

                plans.forEach { (planTitle, desc) ->
                    val isSelected = selectedPlan == planTitle
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isSelected) Color(0x38FFD54F) else Color(0x22132635))
                            .border(1.5.dp, if (isSelected) Color(0xFFFFD54F) else Color(0x3380DEEA), RoundedCornerShape(14.dp))
                            .clickable { selectedPlan = planTitle }
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = planTitle,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color(0xFFFFD54F) else TextPrimary
                                )
                                Text(
                                    text = desc,
                                    fontSize = 10.sp,
                                    color = TextSecondary
                                )
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Color(0xFFFFD54F),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }

                // 4. Payment Gateway (bKash & Nagad)
                Text(
                    text = "পেমেন্ট মাধ্যম (Send Money):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // bKash Button
                    val isBkash = selectedMethod == "bKash"
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isBkash) Color(0x40E2136E) else Color(0x22142230))
                            .border(1.5.dp, if (isBkash) Color(0xFFE2136E) else Color(0x3380DEEA), RoundedCornerShape(12.dp))
                            .clickable { selectedMethod = "bKash" }
                            .padding(10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "বিকাশ (bKash)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFF4081))
                            Text(text = "01712-345678", fontSize = 11.sp, color = TextPrimary)
                        }
                    }

                    // Nagad Button
                    val isNagad = selectedMethod == "Nagad"
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isNagad) Color(0x40F7941D) else Color(0x22142230))
                            .border(1.5.dp, if (isNagad) Color(0xFFF7941D) else Color(0x3380DEEA), RoundedCornerShape(12.dp))
                            .clickable { selectedMethod = "Nagad" }
                            .padding(10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "নগদ (Nagad)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFF9800))
                            Text(text = "01987-654321", fontSize = 11.sp, color = TextPrimary)
                        }
                    }
                }

                // Copy Number Helper
                val currentNumber = if (selectedMethod == "bKash") "01712345678" else "01987654321"
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Payment Number", currentNumber))
                        copyNotice = "$selectedMethod নম্বর কপি করা হয়েছে: $currentNumber"
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x3380DEEA)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp), tint = MayaCyan)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "$selectedMethod নম্বর কপি করুন ($currentNumber)", fontSize = 12.sp, color = MayaCyan)
                }

                if (copyNotice != null) {
                    Text(text = copyNotice!!, fontSize = 11.sp, color = Color(0xFF00E676), fontWeight = FontWeight.Medium)
                }

                // 5. Transaction ID Input
                OutlinedTextField(
                    value = trxIdInput,
                    onValueChange = { trxIdInput = it },
                    label = { Text("Transaction ID (TrxID) লিখুন", color = Color(0xFF90A4AE)) },
                    placeholder = { Text("যেমন: 9J7K3L8M2Q", color = Color(0xFF546E7A)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFFFD54F),
                        unfocusedBorderColor = Color(0x4480DEEA),
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("trx_id_input")
                )

                // 6. Submit Button with golden gradient
                Button(
                    onClick = {
                        if (trxIdInput.isNotBlank()) {
                            onSubmitPayment(selectedMethod, trxIdInput.trim(), selectedPlan)
                        }
                    },
                    enabled = trxIdInput.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFFD54F),
                        contentColor = Color(0xFF07141E)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("submit_payment_button")
                ) {
                    Text(
                        text = "পেমেন্ট নিশ্চিত করুন (Submit TrxID)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // 7. Google Drive 1-Click Cloud Connection Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x22132738))
                        .border(1.dp, Color(0x3300E5FF), RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudDone,
                                contentDescription = null,
                                tint = if (isGoogleDriveLinked) Color(0xFF00E676) else Color(0xFF80DEEA),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Google Drive Cloud Backup",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = if (isGoogleDriveLinked) "সংযুক্ত রয়েছে · ভয়েস ও চ্যাট ড্রাইভ ক্লাউডে সেভ হবে" else "১ ক্লিকে আপনার নিজের গুগল ড্রাইভ কানেক্ট করুন",
                                    fontSize = 10.sp,
                                    color = TextSecondary
                                )
                            }
                        }

                        Button(
                            onClick = { onToggleGoogleDrive(!isGoogleDriveLinked) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isGoogleDriveLinked) Color(0x3300E676) else MayaCyan
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = if (isGoogleDriveLinked) "Connected" else "Connect",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isGoogleDriveLinked) Color(0xFF00E676) else Color(0xFF07141E)
                            )
                        }
                    }
                }

            }
        }
    )
}
