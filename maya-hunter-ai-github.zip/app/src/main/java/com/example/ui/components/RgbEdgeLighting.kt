package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

@Composable
fun RgbEdgeLighting(
    isActive: Boolean,
    modifier: Modifier = Modifier
) {
    if (!isActive) return

    val infiniteTransition = rememberInfiniteTransition(label = "rgb_edge_animation")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rgb_phase"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val strokeWidth = 3.5.dp.toPx()
        val glowWidth = 7.dp.toPx()

        val rgbColors = listOf(
            Color(0xFFFF0055), // Neon Red-Pink
            Color(0xFFFF9900), // Electric Orange
            Color(0xFFFFEE00), // Cyber Yellow
            Color(0xFF00FF66), // Laser Green
            Color(0xFF00E5FF), // Pure Cyan
            Color(0xFF2979FF), // Electric Blue
            Color(0xFFBD00FF), // Neon Purple
            Color(0xFFFF0055)  // Loop
        )

        // Calculate gradient offsets based on phase
        val startX = size.width * phase
        val endX = startX + size.width

        val sweepBrush = Brush.linearGradient(
            colors = rgbColors,
            start = Offset(startX, 0f),
            end = Offset(endX, size.height)
        )

        // Outer soft glow
        drawRect(
            brush = sweepBrush,
            topLeft = Offset(strokeWidth / 2, strokeWidth / 2),
            size = Size(size.width - strokeWidth, size.height - strokeWidth),
            style = Stroke(width = glowWidth),
            alpha = 0.45f
        )

        // Sharp vibrant inner core stroke
        drawRect(
            brush = sweepBrush,
            topLeft = Offset(strokeWidth / 2, strokeWidth / 2),
            size = Size(size.width - strokeWidth, size.height - strokeWidth),
            style = Stroke(width = strokeWidth),
            alpha = 0.95f
        )
    }
}
