package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainTab
import com.example.ui.MayaViewModel
import com.example.ui.components.MayaNavDrawerContent
import com.example.ui.components.MayaSetupDialog
import com.example.ui.components.OfflineOverlay
import com.example.ui.components.PermissionsHubModal
import com.example.ui.components.PremiumSubscriptionModal
import com.example.ui.components.RgbEdgeLighting
import com.example.ui.components.UserProfileModal
import com.example.ui.screens.AgentFleetScreen
import com.example.ui.screens.LiveHudScreen
import com.example.ui.screens.LoginOtpScreen
import com.example.ui.screens.PhoneLinkScreen
import com.example.ui.screens.StudioSettingsScreen
import com.example.ui.screens.TimelineScreen
import com.example.ui.screens.ToolsCatalogScreen
import com.example.ui.theme.MayaBorder
import com.example.ui.theme.MayaCrimson
import com.example.ui.theme.MayaCyan
import com.example.ui.theme.MayaDarkBg
import com.example.ui.theme.MayaEmerald
import com.example.ui.theme.MayaSurface
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: MayaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MayaApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MayaApp(viewModel: MayaViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.voiceEngine.isSpeaking.collectAsStateWithLifecycle()
    val isListening by viewModel.voiceEngine.isListening.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    var isProfileModalOpen by remember { mutableStateOf(false) }
    var isPermissionsModalOpen by remember { mutableStateOf(false) }
    var isPremiumModalOpen by remember { mutableStateOf(false) }
    var isSetupModalOpen by remember { mutableStateOf(false) }

    // 1. Mandatory Login & OTP Verification before entering app
    if (!userProfile.isLoggedIn) {
        LoginOtpScreen(
            onLoginSuccess = { phone, name ->
                viewModel.loginWithOtp(phone, name)
            }
        )
        return
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.voiceEngine.startListening()
        }
    }

    BackHandler(enabled = drawerState.isOpen || uiState.currentTab != MainTab.HUD) {
        if (drawerState.isOpen) {
            scope.launch { drawerState.close() }
        } else {
            viewModel.selectTab(MainTab.HUD)
        }
    }

    LaunchedEffect(uiState.statusNotification) {
        uiState.statusNotification?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearNotification()
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = MayaDarkBg,
                drawerShape = RoundedCornerShape(topEnd = 20.dp, bottomEnd = 20.dp)
            ) {
                MayaNavDrawerContent(
                    currentTab = uiState.currentTab,
                    userProfile = userProfile,
                    onNavigateTab = { tab ->
                        viewModel.selectTab(tab)
                    },
                    onOpenSettings = {
                        isSetupModalOpen = true
                    },
                    onOpenProfile = {
                        isProfileModalOpen = true
                    },
                    onOpenPermissions = {
                        isPermissionsModalOpen = true
                    },
                    onOpenPremium = {
                        isPremiumModalOpen = true
                    },
                    onCloseDrawer = {
                        scope.launch { drawerState.close() }
                    }
                )
            }
        }
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MayaDarkBg,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                CustomBottomBar(
                    currentTab = uiState.currentTab,
                    isSpeaking = isSpeaking,
                    isListening = isListening,
                    onSelectTab = { tab -> viewModel.selectTab(tab) },
                    onMicClick = {
                        val hasAudioPerm = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                        if (!hasAudioPerm) {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        } else {
                            if (isListening) viewModel.voiceEngine.stopListening()
                            else if (isSpeaking) viewModel.interruptSpeaking()
                            else viewModel.voiceEngine.startListening()
                        }
                    }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (uiState.currentTab) {
                    MainTab.HUD -> LiveHudScreen(
                        viewModel = viewModel,
                        onOpenDrawer = { scope.launch { drawerState.open() } },
                        onOpenSetupModal = { isSetupModalOpen = true }
                    )
                    MainTab.TOOLS -> ToolsCatalogScreen(viewModel = viewModel)
                    MainTab.PHONE_LINK -> PhoneLinkScreen(viewModel = viewModel)
                    MainTab.FLEET -> AgentFleetScreen(viewModel = viewModel)
                    MainTab.TIMELINE -> TimelineScreen(viewModel = viewModel)
                    MainTab.STUDIO -> StudioSettingsScreen(viewModel = viewModel)
                }

                // 8GB / RGB Neon Edge Lighting around screen perimeter while voice is active
                RgbEdgeLighting(isActive = isSpeaking || isListening)

                // No Internet Connection Screen blocker
                if (!isOnline) {
                    OfflineOverlay(
                        onRetry = {
                            // Automatically re-checks connection via NetworkCallback
                        }
                    )
                }
            }
        }
    }

    if (isSetupModalOpen) {
        MayaSetupDialog(
            onDismiss = { isSetupModalOpen = false },
            onSaveKey = { key ->
                if (key.isNotBlank()) {
                    viewModel.setModelEndpoint("Google Gemini ($key)")
                }
            },
            onAllowAllPermissions = {
                val hasAudioPerm = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
                if (!hasAudioPerm) {
                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }
        )
    }

    if (isProfileModalOpen) {
        UserProfileModal(
            profile = userProfile,
            onDismiss = { isProfileModalOpen = false },
            onSaveProfile = { name, avatarId ->
                viewModel.updateProfile(name, avatarId)
            },
            onToggleDrive = { enabled ->
                viewModel.toggleDriveSync(enabled)
            },
            onLogout = {
                viewModel.logout()
                isProfileModalOpen = false
            }
        )
    }

    if (isPermissionsModalOpen) {
        PermissionsHubModal(
            hasMicPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED,
            onDismiss = { isPermissionsModalOpen = false },
            onRequestMic = { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) }
        )
    }

    if (isPremiumModalOpen) {
        val subscriptionState by viewModel.subscriptionState.collectAsStateWithLifecycle()
        PremiumSubscriptionModal(
            subscriptionState = subscriptionState,
            onDismiss = { isPremiumModalOpen = false },
            onSubmitPayment = { method, trxId, plan ->
                viewModel.submitPayment(method, trxId, plan)
            },
            onAdminApprove = {
                viewModel.approveProSubscription()
            },
            onToggleGoogleDrive = { connected ->
                viewModel.toggleGoogleDrive(connected)
            }
        )
    }
}

@Composable
private fun CustomBottomBar(
    currentTab: MainTab,
    isSpeaking: Boolean,
    isListening: Boolean,
    onSelectTab: (MainTab) -> Unit,
    onMicClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "mic_pulse")
    val micPulseScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.10f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "mic_scale"
    )

    val waveOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave_anim"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .height(76.dp)
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xF0081622),
                        Color(0xFF040A10)
                    )
                )
            )
            .border(width = 1.dp, color = Color(0x3326C6DA)),
        contentAlignment = Alignment.Center
    ) {
        // Horizontal Audio Soundwave Lines on both sides of central mic
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(40.dp)
        ) {
            val centerY = size.height / 2f
            val centerX = size.width / 2f
            val waveColor = if (isSpeaking) Color(0xFFFF2A4D) else Color(0xFF00E5FF)

            // Left audio wave bars
            val leftBars = 10
            for (i in 0 until leftBars) {
                val x = centerX - 42.dp.toPx() - (i * 7.dp.toPx())
                val h = (4 + (i % 3) * 6 * (if (isSpeaking || isListening) (0.6f + waveOffset * 0.8f) else 0.4f)).dp.toPx()
                drawLine(
                    color = waveColor.copy(alpha = (1.0f - (i.toFloat() / leftBars)) * 0.75f),
                    start = Offset(x, centerY - h / 2f),
                    end = Offset(x, centerY + h / 2f),
                    strokeWidth = 2.dp.toPx(),
                    cap = androidx.compose.ui.graphics.StrokeCap.Round
                )
            }

            // Right audio wave bars
            val rightBars = 10
            for (i in 0 until rightBars) {
                val x = centerX + 42.dp.toPx() + (i * 7.dp.toPx())
                val h = (4 + (i % 3) * 6 * (if (isSpeaking || isListening) (0.6f + waveOffset * 0.8f) else 0.4f)).dp.toPx()
                drawLine(
                    color = waveColor.copy(alpha = (1.0f - (i.toFloat() / rightBars)) * 0.75f),
                    start = Offset(x, centerY - h / 2f),
                    end = Offset(x, centerY + h / 2f),
                    strokeWidth = 2.dp.toPx(),
                    cap = androidx.compose.ui.graphics.StrokeCap.Round
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Home (With blue glowing indicator underneath matching image)
            BottomNavItem(
                title = "Home",
                icon = Icons.Default.Home,
                isSelected = currentTab == MainTab.HUD,
                onClick = { onSelectTab(MainTab.HUD) }
            )

            // Scan / Phone Link (Matching image)
            BottomNavItem(
                title = "Scan",
                icon = Icons.Default.CropFree,
                isSelected = currentTab == MainTab.PHONE_LINK,
                onClick = { onSelectTab(MainTab.PHONE_LINK) }
            )

            // Space for central floating sapphire voice orb
            Spacer(modifier = Modifier.width(66.dp))

            // Memories (Matching image)
            BottomNavItem(
                title = "Memories",
                icon = Icons.Default.Lightbulb,
                isSelected = currentTab == MainTab.STUDIO,
                onClick = { onSelectTab(MainTab.STUDIO) }
            )

            // Chat / Tools (Matching image)
            BottomNavItem(
                title = "Chat",
                icon = Icons.AutoMirrored.Filled.Chat,
                isSelected = currentTab == MainTab.TOOLS,
                onClick = { onSelectTab(MainTab.TOOLS) }
            )
        }

        // Center Sapphire Blue Glowing Voice Orb Button (Matching image 1790949255753.jpg)
        Box(
            modifier = Modifier
                .offset(y = (-14).dp)
                .size(62.dp)
                .scale(if (isListening || isSpeaking) micPulseScale else 1.0f)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            if (isSpeaking) Color(0xFFFF2A4D) else Color(0xFF2979FF),
                            if (isSpeaking) Color(0xFFC71030) else Color(0xFF0D47A1),
                            Color(0xFF041424)
                        )
                    )
                )
                .border(
                    width = 2.dp,
                    color = if (isSpeaking) Color(0xFFFF5252) else Color(0xFF00E5FF),
                    shape = CircleShape
                )
                .clickable { onMicClick() }
                .testTag("floating_mic_center_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                contentDescription = "Voice Control",
                tint = Color.White,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

@Composable
private fun BottomNavItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag("nav_bar_${title.lowercase()}")
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = if (isSelected) Color(0xFF00E5FF) else TextMuted,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = title,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color(0xFF00E5FF) else TextMuted
        )

        // Subtle glowing blue indicator pill underneath Home / selected tab
        if (isSelected) {
            Spacer(modifier = Modifier.height(2.dp))
            Box(
                modifier = Modifier
                    .width(14.dp)
                    .height(3.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF00E5FF))
            )
        }
    }
}
