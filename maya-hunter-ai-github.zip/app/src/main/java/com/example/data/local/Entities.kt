package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tools")
data class EntityTool(
    @PrimaryKey val id: String,
    val name: String,
    val category: String,
    val description: String,
    val examplePrompt: String,
    val isEnabled: Boolean = true,
    val isCore: Boolean = false,
    val invocationCount: Int = 0
)

@Entity(tableName = "command_logs")
data class EntityLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val prompt: String,
    val response: String,
    val category: String,
    val agentUsed: String,
    val outcome: String
)

@Entity(tableName = "memories")
data class EntityMemory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val key: String,
    val content: String,
    val dateAdded: String,
    val category: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "macros")
data class EntityMacro(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val triggerPhrase: String,
    val stepsDescription: String,
    val isScheduled: Boolean = false,
    val scheduleTime: String = "09:00 AM"
)

@Entity(tableName = "otps")
data class EntityOtp(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String,
    val code: String,
    val messageText: String,
    val timestamp: Long = System.currentTimeMillis(),
    val syncedToDesktop: Boolean = true
)

@Entity(tableName = "conversation_messages")
data class EntityChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String, // "USER" or "MAYA"
    val text: String,
    val persona: String = "Maya",
    val executedAction: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "scheduled_tasks")
data class EntityScheduledTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskDescription: String,
    val scheduledTimeDisplay: String,
    val scheduledTimestamp: Long,
    val isCompleted: Boolean = false
)

@Entity(tableName = "subscription_state")
data class EntitySubscription(
    @PrimaryKey val id: Int = 1,
    val planName: String = "Free 3-Day Trial",
    val status: String = "TRIAL_ACTIVE", // TRIAL_ACTIVE, PENDING, PRO_ACTIVE, EXPIRED
    val trialStartDate: Long = System.currentTimeMillis(),
    val trialEndDate: Long = System.currentTimeMillis() + (3L * 24 * 60 * 60 * 1000), // 3 Days
    val paymentMethod: String = "None",
    val trxId: String = "",
    val bkashNumber: String = "01712345678",
    val nagadNumber: String = "01987654321",
    val isGoogleDriveConnected: Boolean = false
)
