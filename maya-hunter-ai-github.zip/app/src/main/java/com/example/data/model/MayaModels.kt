package com.example.data.model

enum class MayaPersona(
    val title: String,
    val subtitle: String,
    val pitch: Float,
    val speechRate: Float,
    val greeting: String
) {
    MAYA(
        title = "Maya",
        subtitle = "Warm & familiar. Speaks naturally, catches tone and hesitation.",
        pitch = 1.1f,
        speechRate = 1.05f,
        greeting = "Hey! What are we working on right now?"
    ),
    FRIDAY(
        title = "Friday",
        subtitle = "Crisp, concise & professional. Highly structured execution.",
        pitch = 0.95f,
        speechRate = 1.15f,
        greeting = "Standing by. Systems connected and ready for input."
    ),
    VENOM(
        title = "Venom",
        subtitle = "Deep-voiced symbiote. Powerful, direct, rude to everyone except you.",
        pitch = 0.65f,
        speechRate = 0.95f,
        greeting = "We are here. What machine shall we break today?"
    )
}

data class CategorySummary(
    val name: String,
    val count: Int,
    val iconKey: String,
    val description: String,
    var isEnabled: Boolean = true
)

data class ToolDefinition(
    val id: String,
    val name: String,
    val category: String,
    val description: String,
    val examplePrompt: String,
    val isEnabled: Boolean = true,
    val isCore: Boolean = false
)

data class TimelineItem(
    val time: String,
    val title: String,
    val userPrompt: String,
    val mayaResponse: String,
    val systemOutcome: String,
    val category: String,
    val iconName: String
)

data class AgentFleetMember(
    val id: String,
    val name: String,
    val type: String,
    val currentMission: String,
    val progress: Float,
    val status: String, // RUNNING, COMPLETED, IDLE, BLOCKED
    val logs: List<String>,
    val engine: String
)

data class PhoneLinkStatus(
    val isPaired: Boolean = true,
    val hostDeviceName: String = "HUNTER-WIN11-PRO",
    val hostIpAddress: String = "192.168.1.104:8080",
    val latencyMs: Int = 11,
    val isDuetModeActive: Boolean = false,
    val isOtpSyncActive: Boolean = true,
    val isNotificationListenerActive: Boolean = true,
    val isVoiceCallActive: Boolean = false,
    val lastSyncTime: String = "Just now",
    val flashlightOn: Boolean = false,
    val volumeLevel: Int = 75
)

data class SpeechEngineSpec(
    val micCaptureRate: String = "16 kHz Native Mic Capture",
    val voiceSynthesisRate: String = "24 kHz Natural Speech Output",
    val latency: String = "180 ms End-to-End",
    val echoSuppression: String = "Hardware + DSP Echo Cancellation",
    val bargeInSupport: Boolean = true,
    val singleModelAudio: Boolean = true
)
