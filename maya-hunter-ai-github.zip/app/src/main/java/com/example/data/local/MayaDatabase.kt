package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        EntityTool::class,
        EntityLog::class,
        EntityMemory::class,
        EntityMacro::class,
        EntityOtp::class,
        EntityChatMessage::class,
        EntityScheduledTask::class,
        EntitySubscription::class
    ],
    version = 2,
    exportSchema = false
)
abstract class MayaDatabase : RoomDatabase() {
    abstract fun mayaDao(): MayaDao

    companion object {
        @Volatile
        private var INSTANCE: MayaDatabase? = null

        fun getDatabase(context: Context): MayaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MayaDatabase::class.java,
                    "maya_companion_database"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
