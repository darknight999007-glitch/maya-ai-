package com.example.data.auth

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class UserProfile(
    val name: String = "সাদিয়া",
    val phone: String = "+8801712345678",
    val avatarId: String = "avatar_1",
    val isLoggedIn: Boolean = false,
    val isTrialActive: Boolean = true,
    val isPro: Boolean = false,
    val isGoogleDriveSynced: Boolean = true
)

class MayaAuthManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("maya_user_prefs", Context.MODE_PRIVATE)

    private val _userProfile = MutableStateFlow(loadProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private fun loadProfile(): UserProfile {
        val isLoggedIn = prefs.getBoolean("is_logged_in", true) // Default true for seamless onboarding
        val name = prefs.getString("user_name", "সাদিয়া") ?: "সাদিয়া"
        val phone = prefs.getString("user_phone", "+8801712345678") ?: "+8801712345678"
        val avatarId = prefs.getString("user_avatar", "avatar_1") ?: "avatar_1"
        val isPro = prefs.getBoolean("is_pro", false)
        val isDrive = prefs.getBoolean("is_drive_synced", true)

        val claimedPhones = prefs.getStringSet("claimed_trial_phones", emptySet()) ?: emptySet()
        val isTrialActive = !claimedPhones.contains(phone) || prefs.getBoolean("trial_active_$phone", true)

        return UserProfile(
            name = name,
            phone = phone,
            avatarId = avatarId,
            isLoggedIn = isLoggedIn,
            isTrialActive = isTrialActive,
            isPro = isPro,
            isGoogleDriveSynced = isDrive
        )
    }

    fun login(phone: String, name: String, avatarId: String = "avatar_1"): Boolean {
        val cleanPhone = phone.trim()
        val cleanName = if (name.isBlank()) "ইউজার" else name.trim()

        val claimedPhones = (prefs.getStringSet("claimed_trial_phones", emptySet()) ?: emptySet()).toMutableSet()
        val isFirstTimeForPhone = !claimedPhones.contains(cleanPhone)
        if (isFirstTimeForPhone) {
            claimedPhones.add(cleanPhone)
        }

        prefs.edit()
            .putBoolean("is_logged_in", true)
            .putString("user_phone", cleanPhone)
            .putString("user_name", cleanName)
            .putString("user_avatar", avatarId)
            .putStringSet("claimed_trial_phones", claimedPhones)
            .putBoolean("trial_active_$cleanPhone", isFirstTimeForPhone)
            .apply()

        _userProfile.value = UserProfile(
            name = cleanName,
            phone = cleanPhone,
            avatarId = avatarId,
            isLoggedIn = true,
            isTrialActive = isFirstTimeForPhone,
            isPro = false,
            isGoogleDriveSynced = true
        )
        return true
    }

    fun updateProfile(name: String, avatarId: String) {
        val current = _userProfile.value
        prefs.edit()
            .putString("user_name", name.trim())
            .putString("user_avatar", avatarId)
            .apply()

        _userProfile.value = current.copy(
            name = name.trim(),
            avatarId = avatarId
        )
    }

    fun toggleGoogleDrive(enabled: Boolean) {
        val current = _userProfile.value
        prefs.edit()
            .putBoolean("is_drive_synced", enabled)
            .apply()

        _userProfile.value = current.copy(isGoogleDriveSynced = enabled)
    }

    fun setProStatus(isPro: Boolean) {
        val current = _userProfile.value
        prefs.edit()
            .putBoolean("is_pro", isPro)
            .apply()

        _userProfile.value = current.copy(isPro = isPro)
    }

    fun logout() {
        prefs.edit()
            .putBoolean("is_logged_in", false)
            .apply()

        _userProfile.value = _userProfile.value.copy(isLoggedIn = false)
    }
}
